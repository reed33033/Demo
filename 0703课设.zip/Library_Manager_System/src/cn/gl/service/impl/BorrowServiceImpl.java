package cn.gl.service.impl;

import java.util.List;
import java.util.Set;

import cn.gl.dbc.DatabaseConnection;
import cn.gl.factory.DAOFactory;
import cn.gl.service.IBorrowService;
import cn.gl.vo.Borrow;
/**
 * 本类为IBorrowService的实现类
 * @author 高丽
 * @version V1.0
 */
public class BorrowServiceImpl implements IBorrowService {
	// 取得数据库连接对象
	private DatabaseConnection dbc = new DatabaseConnection();

	/**
	 * 实现借书信息增加操作，在本操作中需要使用IBorrowDAO接口中的如下方法：<br>
	 * <li>使用IBorrowDAO.doCreate()方法保存借书记录信息</li>
	 * 
	 * @param borrow 包含了要增加数据的Borrow类对象
	 * @return 数据增加成功返回true，否则返回false
	 * @throws Exception IBorrowDAO接口中的抛出异常
	 */
	@Override
	public boolean insert(Borrow borrow) throws Exception {
		return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).doCreate(borrow);

	}

	/**
	 * 实现还书操作，调用的是IBorrowDAO.doUpdate()方法
	 * 
	 * @param borrow 包含要修改的数据信息
	 * @return 修改成功返回true,否则返回false
	 * @throws Exception IBorrowDAO接口中的抛出异常
	 */

	@Override
	public boolean update(Borrow borrow) throws Exception {
		try {
			return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).doUpdate(borrow);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 实现数据的删除操作，即还书操作，在本操作中需要执行如下调用：<br>
	 * <li>判断要删除数据传入的集合内容是否为空（判断null以及size）</li>
	 * <li>如果确定有删除的数据，则调用IBorrowDAO.doRemove()方法删除</li>
	 * 
	 * @param ids 包含了要删除数据的所有Id内容
	 * @return 删除成功返回true,否则返回false
	 * @throws Exception IBorrowDAO接口中的抛出异常
	 */
	@Override
	public boolean delete(Set<Integer> ids) throws Exception {
		try {
			if (ids.size() == 0) {
				return false;
			}
			return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).doRemove(ids);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 根据借书记录编号查询借书记录，调用的是IBorrowDAO.findId()方法查询
	 * 
	 * @param id 要查询的借书编号
	 * @return 如果可以查询到借书记录则以Borrow的形式返回，如果查询不到则返回null
	 * @throws Exception IBorrowDAO接口中的抛出异常
	 */
	@Override
	public Borrow get(Integer id) throws Exception {
		try {
			return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).findById(id);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 根据读者编号查询借书记录，调用的是IBorrowDAO.findReaderId()方法查询
	 * 
	 * @param readerid 要查询的读者编号
	 * @return 所有的查询记录，以List集合返回
	 * @throws Exception IBorrowDAO接口中的抛出异常
	 */
	public List<Borrow> getReader(Integer id) throws Exception {
		try {
			return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).findByReaderId(id);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 根据读者编号和书籍查询出一个这条借书记录的完整信息，调用的是IEmpDAO.findByISBN()方法查询
	 * 
	 * @param readerId 要借书记录的读者编号
	 * @param ISBN     要查询借书记录的图书编号
	 * @return 如果可以查询到借书记录则以Borrow的形式返回，如果查询不到则返回null
	 * @throws Exception IBorrowDAO接口中的抛出异常
	 */
	public Borrow getBook(Integer readerId, String ISBN) throws Exception {
		try {
			return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).findByISBN(readerId, ISBN);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 按字段排序取得所有数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Borrow> Order(String name, String choose) throws Exception {
		try {
			return DAOFactory.getIBorrowDAOInstance(this.dbc.getConnection()).OrderAll(name, choose);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

}
