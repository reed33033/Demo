package cn.gl.service.impl;

import java.util.List;
import java.util.Set;

import cn.gl.factory.DAOFactory;
import cn.gl.service.IUserService;
import cn.gl.vo.User;

/**
 * 本来为IUserService的实现类，当取得了本类对象时，就意味着可以进行数据库操作了。
 * 
 * @author 高丽
 * @version V1.0
 */
public class UserServiceImpl implements IUserService {
	/**
	 * 实现用户信息增加操作，在本操作中需要使用IUserDAO接口中的如下方法：<br>
	 * <li>首先要利用IUserDAO.findById()方法判断要增加的用户编号是否存在。</li>
	 * <li>如果用户编号不存在，则使用IUserDAO.doCreate()方法保存用户信息</li>
	 * 
	 * @param user 包含了要增加数据的User类对象
	 * @return 数据增加成功返回true，否则返回false
	 * @throws Exception IUserDAO接口中的抛出异常
	 */
	@Override
	public boolean insert(User user) throws Exception {
		if (DAOFactory.getIUserDAOInstance().findById(user.getUserName()) == null) {
			return DAOFactory.getIUserDAOInstance().doCreate(user);
		}
		return false;
	}

	/**
	 * 实现数据的修改操作，调用的是IUserDAO.doUpdate()方法，此操作属于全部修改
	 * 
	 * @param user 包含了要增加数据的User类对象
	 * @return 修改成功返回true,否则返回false
	 * @throws Exception IUserDAO接口中的抛出异常
	 */
	@Override
	public boolean update(User user) throws Exception {
		return DAOFactory.getIUserDAOInstance().doUpdate(user);
	}

	/**
	 * 实现数据的删除操作，在本操作中需要执行如下调用：<br>
	 * <li>判断要删除数据传入的内容是否为空（判断null）</li>
	 * <li>如果确定有删除的数据，则调用IUserDAO.doRemove()方法删除</li>
	 * 
	 * @param username 要删除的用户名
	 * @return 删除成功返回true,否则返回false
	 * @throws Exception IUserDAO接口中的抛出异常
	 */
	@Override
	public boolean delete(String username) throws Exception {

		return DAOFactory.getIUserDAOInstance().doRemove(username);

	}

	/**
	 * 根据用户名查询出一个用户的完整信息，调用的是IUserDAO.findById()方法查询
	 * 
	 * @param username 要查询的用户编号信息
	 * @return 如果可以查询到用户则以User的形式返回，如果查询不到则返回null
	 * @throws Exception IUserDAO接口中的抛出异常
	 */
	@Override
	public User get(String username) throws Exception {

		return DAOFactory.getIUserDAOInstance().findById(username);
	}

	/**
	 * 查询用户的全部数据，调用的是IUserDAO.findAll()方法查询
	 * 
	 * @return 所有的查询记录
	 * @throws Exception IUserDAO接口中的抛出异常
	 */
	@Override
	public List<User> list() throws Exception {
		return DAOFactory.getIUserDAOInstance().findAll();

	}

	/**
	 * 用户登录，根据用户编号查询出一个用户的完整信息，调用的是IUserDAO.findByName()方法查询
	 * 
	 * @param userName 用户名
	 * @param password 密码
	 * @return 如果可以查询到用户则以User的形式返回，如果查询不到则返回null
	 */
	@Override
	public User userLogin(String userName, String password) throws Exception {
		return DAOFactory.getIUserDAOInstance().findByName(userName, password);
	}

	/**
	 * 按字段排序取得所有数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<User> Order(String name, String choose) throws Exception {
		return DAOFactory.getIUserDAOInstance().OrderAll(name, choose);
	}

}
