package cn.gl.service.impl;

import java.util.List;
import java.util.Set;

import cn.gl.dbc.DatabaseConnection;
import cn.gl.factory.DAOFactory;
import cn.gl.service.IReaderService;
import cn.gl.vo.Reader;
/**
 * 本类为IReaderService的实现类
 * @author 高丽
 * @version V1.0
 */

public class ReaderServiceImpl implements IReaderService{
	// 取得数据库连接对象
	 private DatabaseConnection dbc = new DatabaseConnection();
	 /**
		 * 实现数据的修改操作，调用的是IReaderDAO.doUpdate()方法，此操作属于全部修改
		 * 
		 * @param reader 包含要修改的数据信息
		 * @return 修改成功返回true,否则返回false
		 * @throws Exception IReaderDAO接口中的抛出异常
		 */
	    @Override
	    public boolean update(Reader reader) throws Exception {
	        try {
	            return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).doUpdate(reader);
	        }catch (Exception e) {
	            throw e;
	        }finally {
	            this.dbc.close();
	        }
	    }
	    /**
		 * 根据读者编号查询出一个读者的完整信息，调用的是IReaderTypeDAO.findById()方法查询
		 * 
		 * @param id 要查询的读者编号信息
		 * @return 如果可以查询到图书则以Reader的形式返回，如果查询不到则返回null
		 * @throws Exception IReaderDAO接口中的抛出异常
		 */
	    @Override
	    public Reader get(Integer id) throws Exception {
	        try {
	            return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).findById(id);
	        }catch (Exception e) {
	            throw e;
	        }finally {
	            this.dbc.close();
	        }
	    }
	    /**
		 * 实现读者信息增加操作，在本操作中需要使用IReaderUserDAO接口中的如下方法：<br>
		 * <li>首先要利用IReaderDAO.findById()方法判断要增加的用户编号是否存在。</li>
		 * <li>如果用户编号不存在，则使用IUserDAO.doCreate()方法保存用户信息</li>
		 * 
		 * @param reader 包含了要增加数据的Reader类对象
		 * @return 数据增加成功返回true，否则返回false
		 * @throws Exception IReaderDAO接口中的抛出异常
		 */
		@Override
		public boolean insert(Reader reader) throws Exception {
			 if(DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).findById(reader.getReaderId()) == null) {
	                return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).doCreate(reader);
	            }
	            return false;
		}
		/**
		 * 实现数据的删除操作，在本操作中需要执行如下调用：<br>
		 * <li>判断要删除数据传入的内容是否为空（判断null）</li>
		 * <li>如果确定有删除的数据，则调用IReaderDAO.doRemove()方法删除</li>
		 * 
		 * @param ids 要删除的读者编号
		 * @return 删除成功返回true,否则返回false
		 * @throws Exception IReaderUserDAO接口中的抛出异常
		 */
		@Override
		public boolean delete(Set<Integer> ids) throws Exception {
			 try {
		            if(ids.size() ==0) {
		                return false;
		            }
		            return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).doRemove(ids);
		        }catch (Exception e) {
		            throw e;
		        }finally {
		            this.dbc.close();
		        }
		}
		/**
		 * 查询用户的全部数据，调用的是IReaderDAO.findAll()方法查询
		 * 
		 * @return 所有的查询记录
		 * @throws Exception IReaderDAO接口中的抛出异常
		 */
		@Override
		public List<Reader> findAll() throws Exception {
			return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).findAll();
		}
		/**
		 * 得到数据表最后一条数据，以便自动设置添加的编号，调用的是IReaderTypeDAO.findLast()方法查询
		 * 
		 * @return 如果可以查询到图书则以Reader的形式返回，如果查询不到则返回null
		 * @throws Exception IReaderDAO接口中的抛出异常
		 */
		@Override
		public Reader findLastId() throws Exception {
			return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).findLast();
		}
		/**
		 * 根据读者名字出一个读者的完整信息，调用的是IReaderTypeDAO.findByName()方法查询
		 * 
		 * @param name 要查询的读者名字编号信息
		 * @return 如果可以查询到图书则以Reader的形式返回，如果查询不到则返回null
		 * @throws Exception IReaderDAO接口中的抛出异常
		 */
		@Override
		public List<Reader> get(String name) throws Exception {
			return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).findByName(name);
		}
		/**
		 * 按字段排序取得所有数据信息
		 * 
		 * @param name   要进行排序的字段名
		 * @param choose 排序的方式，desc为降序，asc为升序
		 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
		 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
		 */
		@Override
		public List<Reader> Order(String name, String choose) throws Exception {
			return DAOFactory.getIReaderDAOInstance(this.dbc.getConnection()).OrderAll(name, choose);
		}
		
}
