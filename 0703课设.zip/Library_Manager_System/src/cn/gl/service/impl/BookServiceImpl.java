package cn.gl.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cn.gl.dbc.DatabaseConnection;
import cn.gl.factory.DAOFactory;
import cn.gl.service.IBookService;
import cn.gl.vo.Book;
/**
 * 本类为IBookService的实现类
 * @author 高丽
 * @version V1.0
 */
public class BookServiceImpl implements IBookService {
	// 取得数据库连接对象
	private DatabaseConnection dbc = new DatabaseConnection();

	/**
	 * 实现数据的修改操作，调用的是IBookDAO.doUpdate()方法，此操作属于全部修改
	 * 
	 * @param book 包含要修改的数据信息
	 * @return 修改成功返回true,否则返回false
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public boolean update(Book book) throws Exception {
		try {
			return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).doUpdate(book);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 根据图书编号查询出一个图书的完整信息，调用的是IBookDAO.findById()方法查询
	 * 
	 * @param id 要查询的图书编号信息
	 * @return 如果可以查询到图书则以Book的形式返回，如果查询不到则返回null
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public Book get(String id) throws Exception {
		try {
			return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findById(id);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 根据图书名称查询相关图书的完整信息，调用的是IBookDAO.findByName()方法查询
	 * 
	 * @param bookname 要查询的图书名称
	 * @return 如果可以查询到图书则以集合的形式返回，如果查询不到则返回null
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public List<Book> findbook(String bookname) throws Exception {
		try {
			return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findByName(bookname);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * @return 返回所以的书籍信息
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public List<Book> getAll() throws Exception {
		return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findAll();
	}

	/**
	 * 得到数据表最后一条数据，以便自动设置添加的编号，调用的是IBookDAO.findLast()方法查询
	 * 
	 * @return 如果可以查询到图书则以Book的形式返回，如果查询不到则返回null
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public Book findLastId() throws Exception {
		return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findLast();
	}

	/**
	 * 实现图书信息增加操作，在本操作中需要使用IBookDAO接口中的如下方法：<br>
	 * <li>使用IBookDAO.doCreate()方法保存雇员信息</li>
	 * 
	 * @param book 包含了要增加数据的Book对象
	 * @return 数据增加成功返回true，否则返回false
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public boolean insert(Book book) throws Exception {
		try {
			if (DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findById(book.getISBN()) == null) {
				if (DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findByName(book.getBookName()).size() == 0)
					return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).doCreate(book);
			}
			return false;
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 实现数据的删除操作，在本操作中需要执行如下调用：<br>
	 * <li>判断要删除数据传入的集合内容是否为空（判断null以及size）</li>
	 * <li>如果确定有删除的数据，则调用IBookDAO.doRemove()方法删除</li>
	 * 
	 * @param ids 包含了要删除数据的所有Id内容
	 * @return 删除成功返回true,否则返回false
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public boolean delete(Set<String> ids) throws Exception {
		try {
			if (ids.size() == 0) {
				return false;
			}
			return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).doRemove(ids);
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
		}
	}

	/**
	 * 实现数据模糊查询操作，同时会返回符合查询要求的数据量，本次操作要调用以下的功能：<br>
	 * <li>调用IBook.findAllSplit()方法，分页查询要显示的数据</li>
	 * <li>调用IBookDAO.getAllCount()方法，统计数据的个数</li>
	 * 
	 * @param column      模糊查询字段
	 * @param keyWord     模糊查询关键字
	 * @param currentPage 当前所在页
	 * @param lineSize    每页显示的长度
	 * @return 本方法要返回两个数据，所有使用Map集合返回，出现的内容如下：<br>
	 *         <li>key = allBooks、value =
	 *         IBookDAO.findAllSplit()，返回的是List&lt;Emp&gt;</li>
	 *         <li>key = BookCount、value = IBookDAO.getAllCount(),返回的是Integer</li>
	 * @throws Exception IBookDAO接口中的抛出异常
	 */
	@Override
	public Map<String, Object> listSplit(String column, String keyWord, int currentPage, int lineSize)
			throws Exception {
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("allEmps", DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).findAllSplit(column, keyWord,
					currentPage, lineSize));
			map.put("empCount", DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).getAllCount(column, keyWord));
			return map;
		} catch (Exception e) {
			throw e;
		} finally {
			this.dbc.close();
			;
		}
	}

	/**
	 * 实现统计数据表中符合查询要求的数据量
	 * <li>调用IBookDAO.getAllCount()方法，统计数据的个数</li>
	 * 
	 * @param column  要查询的字段名
	 * @param keyWord 要查询的关键字
	 * @param return  返回COUNT()的统计结果，如果没有数据满足，则返回内容为0
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public Integer getCount(String columun, String keyWord) throws Exception {
		return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).getAllCount(columun, keyWord);
	}

	/**
	 * 按字段排序取得所有数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Book> Order(String name, String choose) throws Exception {
		return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).OrderAll(name, choose);
	}

	/**
	 * 清空图书表内的所有数据，即删除所有数据
	 * 
	 * @return 如果删除成功则返回true，失败返回false
	 */
	@Override
	public Boolean deleteAll() {
		return DAOFactory.getIBookDAOInstance(this.dbc.getConnection()).doRemoveAll();
	}

}
