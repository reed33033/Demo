package cn.gl.service;

import java.util.List;
import java.util.Set;

import cn.gl.vo.Book;
import cn.gl.vo.BookType;
/**
 * 本类为图书表业务层的操作标准
 * @author 高丽
 * @version V1.0
 *
 */
public interface IBookTypeService {
	/**
	 * 根据图书类别编号查询出一个图书类别的完整信息，调用的是IBookTypeDAO.findById()方法查询
	 * 
	 * @param id 要查询的图书类别编号信息
	 * @return 如果可以查询到图书则以BookType的形式返回，如果查询不到则返回null
	 * @throws Exception IBookTypeDAO接口中的抛出异常
	 */
	public BookType get(Integer id) throws Exception;

	/**
	 * 根据图书类别名称查询出一个图书类别的完整信息，调用的是IBookTypeDAO.findByName()方法查询
	 * 
	 * @param typeName 要查询的图书类别编号信息
	 * @return 如果可以查询到图书则以BookType的形式返回，如果查询不到则返回null
	 * @throws Exception IBookTypeDAO接口中的抛出异常
	 */
	public List<BookType> get(String typename) throws Exception;

	/**
	 * 得到数据表最后一条数据，以便自动设置添加的类别编号，调用的是IBookTypeDAO.findLast()方法查询
	 * 
	 * @return 如果可以查询到图书则以BookType的形式返回，如果查询不到则返回null
	 * @throws Exception IBookTypeDAO接口中的抛出异常
	 */
	public BookType findLastId() throws Exception;

	/**
	 * 实现图书类别信息增加操作，在本操作中需要使用IBookTypeDAO接口中的如下方法：<br>
	 * <li>使用IBookTypeDAO.doCreate()方法保存雇员信息</li>
	 * 
	 * @param booktype 包含了要增加数据的BookType类对象
	 * @return 数据增加成功返回true，否则返回false
	 * @throws Exception IBookTypeDAO接口中的抛出异常
	 */
	public boolean insert(BookType booktype) throws Exception;

	/**
	 * 实现数据的修改操作，调用的是IBookType.doUpdate()方法，此操作属于全部修改
	 * 
	 * @param booktype 包含要修改的数据信息
	 * @return 修改成功返回true,否则返回false
	 * @throws Exception IBookTypeDAO接口中的抛出异常
	 */
	public boolean update(BookType booktype) throws Exception;

	/**
	 * 实现数据的删除操作，在本操作中需要执行如下调用：<br>
	 * <li>判断要删除数据传入的集合内容是否为空（判断null以及size）</li>
	 * <li>如果确定有删除的数据，则调用IBookTypeDAO.doRemove()方法删除</li>
	 * 
	 * @param ids 包含了要删除数据的所有Id内容
	 * @return 删除成功返回true,否则返回false
	 * @throws Exception IBookTypeDAO接口中的抛出异常
	 */
	public boolean delete(Set<Integer> ids) throws Exception;

	/**
	 * 查询图书类别的全部数据，调用的是IBookTypeEmpDAO.findAll()方法查询
	 * 
	 * @return 所有的查询记录，以List集合返回
	 * @throws Exception IBookTypepDAO接口中的抛出异常
	 */
	public List<BookType> list() throws Exception;

	/**
	 * 按字段排序取得所有数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<BookType> Order(String name, String choose) throws Exception;
}
