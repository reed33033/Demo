package cn.gl.factory;

import cn.gl.service.IBookService;
import cn.gl.service.IBookTypeService;
import cn.gl.service.IBorrowService;
import cn.gl.service.IReaderService;
import cn.gl.service.IUserService;
import cn.gl.service.impl.BookServiceImpl;
import cn.gl.service.impl.BookTypeServiceImpl;
import cn.gl.service.impl.BorrowServiceImpl;
import cn.gl.service.impl.ReaderServiceImpl;
import cn.gl.service.impl.UserServiceImpl;

/**
 * 当取得了本类对象时，就意味着可以进行数据库操作了。
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class ServiceFactory {
	/**
	 * 获得IUserService实例
	 * 
	 * @return IUserService 实例
	 */
	public static IUserService getIUserServiceInstance() {
		return new UserServiceImpl();
	}

	/**
	 * 获取 IBookService实例
	 * 
	 * @return IBookService实例
	 */
	public static IBookService getIBookServiceInstance() {
		return new BookServiceImpl();
	}

	/**
	 * 获取IBookTypeService实例
	 * 
	 * @return IBookTypeService实例
	 */
	public static IBookTypeService getIBookTypeServiceInstance() {
		return new BookTypeServiceImpl();
	}

	/**
	 * 获取IBorrowService实例
	 * 
	 * @return IBorrowService实例
	 */
	public static IBorrowService getIBorrowServiceInstance() {
		return new BorrowServiceImpl();
	}

	/**
	 * 获取IReaderService实例
	 * 
	 * @return IReaderService实例
	 */
	public static IReaderService getIReaderServiceInstance() {
		return new ReaderServiceImpl();
	}
}
