package cn.gl.factory;

import java.sql.Connection;

import cn.gl.dao.IBookDAO;
import cn.gl.dao.IBookTypeDAO;
import cn.gl.dao.IBorrowDAO;
import cn.gl.dao.IReaderDAO;
import cn.gl.dao.IUserDAO;
import cn.gl.dao.impl.BookDAOImpl;
import cn.gl.dao.impl.BookTypeDAOImpl;
import cn.gl.dao.impl.BorrowDAOImpl;
import cn.gl.dao.impl.ReaderDAOImpl;
import cn.gl.dao.impl.UserDAOImpl;
/**
 * 本类是数据层工厂类
 * @author 高丽
 * @version V1.0
 *
 */
public class DAOFactory {
	/**
	  * 获得IUserDao实例
	  * @return IUserDao 实例
	  */
	 public static IUserDAO getIUserDAOInstance() {
	        return new UserDAOImpl();
	    }
	 /**
	  * 获得IBookDao实例
	  * @param conn 数据库连接对象
	  * @return IBookDao实例
	  */
	 public static IBookDAO getIBookDAOInstance(Connection conn) {
	        return new BookDAOImpl(conn);
	    }
	 /**
	  * 获得IBookTypeDAO实例
	  * @param conn 数据库连接对象
	  * @return IBookTypeDAO实例
	  */
	 public static IBookTypeDAO getIBookTypeDAOInstance(Connection conn) {
	        return new BookTypeDAOImpl(conn);
	    }
	 /**
	  * 获得IBorrowDAO实例
	  * @param conn 数据库对象
	  * @return IBorrowDAO实例
	  */
	 public static IBorrowDAO getIBorrowDAOInstance(Connection conn) {
	        return new BorrowDAOImpl(conn);
	    }
	 /**
	  * 获得IReaderDAO实例
	  * @param conn 数据库对象
	  * @return IReaderDAO实例
	  */
	 public static IReaderDAO getIReaderDAOInstance(Connection conn) {
	        return new ReaderDAOImpl(conn);
	    }
}
