package cn.gl.test.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Reader;
import junit.framework.TestCase;

class IReaderServiceTest {

	@Test
	void testInsert() {
		Reader read=new Reader();
		read.setKeepMoney((Double)23.8);
		read.setMaxNum(Integer.valueOf(2));
		read.setReaderAge(Integer.valueOf(22));
		read.setReaderId(Integer.valueOf(10006));
		read.setReaderIdCard("121213435657897098");
		read.setReaderName("12wed");
		read.setReaderPhone("64738293874");
		read.setReaderSex("女");
		read.setRegdate(new java.util.Date());
		try {
			TestCase.assertTrue(ServiceFactory.getIReaderServiceInstance().insert(read));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testDelete() {
		Set<Integer> all=new HashSet<Integer>();
		all.add(Integer.valueOf(10005));
		try {
			TestCase.assertTrue(ServiceFactory.getIReaderServiceInstance().delete(all));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testUpdate() {
		Reader read=new Reader();
		read.setKeepMoney((double) 40);
		read.setMaxNum(Integer.valueOf(3));
		read.setReaderAge(Integer.valueOf(22));
		read.setReaderId(Integer.valueOf(10004));
		read.setReaderIdCard("121213435657897098");
		read.setReaderName("兔兔");
		read.setReaderPhone("64738293874");
		read.setReaderSex("女");
		read.setRegdate(new java.util.Date());
		try {
			TestCase.assertTrue(ServiceFactory.getIReaderServiceInstance().update(read));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetInteger() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIReaderServiceInstance().get(Integer.valueOf(10003)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetString() {
		try {
			TestCase.assertTrue(ServiceFactory.getIReaderServiceInstance().get("李四").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testFindAll() {
		try {
			TestCase.assertTrue(ServiceFactory.getIReaderServiceInstance().findAll().size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testFindLastId() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIReaderServiceInstance().findLastId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testOrder() {
		try {
			TestCase.assertTrue(ServiceFactory.getIReaderServiceInstance().Order("readerId", "asc").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
