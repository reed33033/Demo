package cn.gl.test.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Book;
import junit.framework.TestCase;

class IBookServiceTest {
	@Test
	void testInsert() {
		Book book=new Book();
		book.setAmount(Integer.valueOf(2));
		book.setAuthor("啦啦啦我也不知道");
		book.setISBN("1012094");
		book.setBookName("《知道》");
		book.setPublish("知道");
		book.setPublishDate(new java.util.Date());
		book.setTypeId(Integer.valueOf(2));
		book.setUnitPrice((Double)23.8);
		try {
			TestCase.assertTrue(ServiceFactory.getIBookServiceInstance().insert(book));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	void testUpdate() {
		Book book=new Book();
		book.setAmount(2);
		book.setAuthor("21不知道");
		book.setBookName("12知道");
		book.setISBN("1012092");
		book.setPublish("bzd");
		book.setPublishDate(new java.util.Date());
		book.setTypeId(2);
		book.setUnitPrice(23.5);
		try {
			TestCase.assertTrue(ServiceFactory.getIBookServiceInstance().update(book));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGet() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBookServiceInstance().get("1012092"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetAll() {
		try {
			TestCase.assertTrue(ServiceFactory.getIBookServiceInstance().getAll().size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testFindbook() {
		try {
			TestCase.assertTrue(ServiceFactory.getIBookServiceInstance().findbook("我").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testFindLastId() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBookServiceInstance().findLastId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	@Test
	void testDelete() {
		Set<String> all=new HashSet<String>();
		all.add("1012093");
		try {
			TestCase.assertTrue(ServiceFactory.getIBookServiceInstance().delete(all));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
