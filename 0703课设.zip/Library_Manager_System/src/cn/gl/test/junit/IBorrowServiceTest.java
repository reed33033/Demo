package cn.gl.test.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Borrow;
import junit.framework.TestCase;

class IBorrowServiceTest {

	@Test
	void testInsert() {
		Borrow borrow=new Borrow();
		borrow.setBorrowDate(new java.util.Date());
		borrow.setBorrowId(Integer.valueOf(10));
		borrow.setFine((Double)2.5);
		borrow.setISBN("1000000");
		borrow.setReaderId(Integer.valueOf(1000));
		borrow.setReturnDate(new java.util.Date());
		borrow.setUserName("张三");
		try {
			TestCase.assertTrue(ServiceFactory.getIBorrowServiceInstance().insert(borrow));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGet() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBorrowServiceInstance().get(Integer.valueOf(10)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetReader() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBorrowServiceInstance().getReader(Integer.valueOf(10000)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetBook() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBorrowServiceInstance().getBook(Integer.valueOf(10000), "1000000"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testUpdate() {
		Borrow borrow=new Borrow();
		borrow.setBorrowDate(new java.util.Date());
		borrow.setBorrowId(Integer.valueOf(10));
		borrow.setFine((Double)3.5);
		borrow.setISBN("1000003");
		borrow.setReaderId(Integer.valueOf(1000));
		borrow.setReturnDate(new java.util.Date());
		borrow.setUserName("李四");
		try {
			TestCase.assertNotNull(ServiceFactory.getIBorrowServiceInstance().update(borrow));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testDelete() {
		Set<Integer> all=new HashSet<Integer>();
		all.add(Integer.valueOf(11));
		try {
			TestCase.assertTrue(ServiceFactory.getIBorrowServiceInstance().delete(all));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testOrder() {
		try {
			TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().Order("borrowId", "asc").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
