package cn.gl.test.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;
import junit.framework.TestCase;

class IBookTypeServiceTest {

	@Test
	void testGetInteger() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBookTypeServiceInstance().get(Integer.valueOf(8)));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGetString() {
		try {
			TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().get("历史").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testFindLastId() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIBookTypeServiceInstance().findLastId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testInsert() {
		BookType type=new BookType();
	type.setTypeId(Integer.valueOf(9));
	type.setTypeName("物理");
		try {
			TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().insert(type));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testUpdate() {
		BookType type=new BookType();
		type.setTypeId(Integer.valueOf(7));
		type.setTypeName("美术");
			try {
				TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().update(type));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	@Test
	void testDelete() {
		Set<Integer> all=new HashSet<Integer>();
		all.add(Integer.valueOf(8));
		try {
			TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().delete(all));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testList() {
		try {
			TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().list().size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testOrder() {
		try {
			TestCase.assertTrue(ServiceFactory.getIBookTypeServiceInstance().Order("typeId", "asc").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
