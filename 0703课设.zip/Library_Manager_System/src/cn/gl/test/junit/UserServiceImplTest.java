package cn.gl.test.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.User;
import junit.framework.TestCase;

class UserServiceImplTest {

	@Test
	void testInsert() {
		User user=new User();
		user.setUserName("不知道");
		user.setPassword("qwert");
		try {
			TestCase.assertTrue(ServiceFactory.getIUserServiceInstance().insert(user));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testUpdate() {
		User user=new User();
		user.setUserName("frg");
		user.setPassword("qwert");
		try {
			TestCase.assertTrue(ServiceFactory.getIUserServiceInstance().update(user));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testDelete() {
		try {
			TestCase.assertTrue(ServiceFactory.getIUserServiceInstance().delete("mlo"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testGet() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIUserServiceInstance().get("yui"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testList() {
		try {
			TestCase.assertTrue(ServiceFactory.getIUserServiceInstance().list().size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testUserLogin() {
		try {
			TestCase.assertNotNull(ServiceFactory.getIUserServiceInstance().userLogin("yui", "789"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	void testOrder() {
		try {
			TestCase.assertTrue(ServiceFactory.getIUserServiceInstance().Order("userName", "desc").size()>0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
