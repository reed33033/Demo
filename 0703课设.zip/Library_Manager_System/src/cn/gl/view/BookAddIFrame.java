package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.eltima.components.ui.DatePicker;

import cn.gl.factory.ServiceFactory;
import cn.gl.view.ReaderAddIFrame.ButtonAddListener;
import cn.gl.view.ReaderAddIFrame.NumberListener;
import cn.gl.view.ReaderAddIFrame.TelListener;
import cn.gl.view.ReaderAddIFrame.TimeActionListener;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;

/**
 * 本类为图书添加窗体
 * @author 高丽
 * @version V1.0
 */

class toStringtype {
	public String typeid;
	public String typename;

	public String getTypeid() {
		return typeid;
	}

	public void setTypeid(String typeid) {
		this.typeid = typeid;
	}

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}

	public String toString() {
		return getTypename();
	}

}

public class BookAddIFrame extends JInternalFrame {
	private ButtonGroup buttonGroup = new ButtonGroup();
	private JFormattedTextField pricetxt;
	private JFormattedTextField publishtxt;
	private JFormattedTextField numbertxt;
	private JTextField authortxt;
	private JTextField nametxt;
	private JTextField ISBNtxt;
	private JComboBox booktype;
	DefaultComboBoxModel bookTypeModel;
	SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new java.util.Date();
	String[] array;

	private static BookAddIFrame bookaddfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized BookAddIFrame GetInstance() {
		if (bookaddfm == null) {
			bookaddfm = new BookAddIFrame();
		}
		return bookaddfm;
	}

	private static DatePicker getDatePicker() {
		final DatePicker datepick;
		// 格式
		String DefaultFormat = "yyyy-MM-dd HH:mm:ss";
		// 当前时间
		Date date = new Date();
		// 字体
		Font font = new Font("Times New Roman", Font.BOLD, 14);

		Dimension dimension = new Dimension(177, 24);

		int[] hilightDays = { 1, 3, 5, 7 };

		// int[] disabledDays = { 4, 6, 5, 9 };

		datepick = new DatePicker(date, DefaultFormat, font, dimension);

		datepick.setLocation(137, 83);
		datepick.setBounds(137, 83, 177, 24);
		// 设置一个月份中需要高亮显示的日子
		datepick.setHightlightdays(hilightDays, Color.red);
		// 设置一个月份中不需要的日子，呈灰色显示
		// datepick.setDisableddays(disabledDays);
		// 设置国家
		datepick.setLocale(Locale.CHINA);
		// 设置时钟面板可见
		datepick.setTimePanleVisible(true);
		return datepick;
	}

	/**
	 * Create the frame
	 */
	public BookAddIFrame() {
		setTitle("图书相关信息添加");
		setIconifiable(true); // 设置窗体可最小化－－－必须
		setClosable(true); // 设置窗体可关闭－－－必须
							// 设置窗体标题－－－必须
		setBounds(100, 100, 499, 519);

		final JPanel panel = new JPanel();
		getContentPane().add(panel);
		panel.setLayout(null);

		final JPanel panel_1 = new JPanel();
		panel_1.setBounds(15, 5, 450, 403);
		final GridLayout gridLayout = new GridLayout(0, 2);
		gridLayout.setVgap(15);
		gridLayout.setHgap(10);
		panel_1.setLayout(gridLayout);
		panel_1.setPreferredSize(new Dimension(450, 200));
		panel.add(panel_1);

		final JLabel label_2 = new JLabel();
		label_2.setFont(new Font("宋体", Font.PLAIN, 20));
		label_2.setText("图书编号：");
		panel_1.add(label_2);

		ISBNtxt = new JTextField();
		ISBNtxt.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(ISBNtxt);
		ISBNtxt.setEditable(false);
		Book book = null;
		try {
			book = ServiceFactory.getIBookServiceInstance().findLastId();
			ISBNtxt.setText(String.valueOf(Integer.valueOf(book.getISBN()) + 1));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		final JLabel label_3 = new JLabel();
		label_3.setFont(new Font("宋体", Font.PLAIN, 20));
		label_3.setText("图书类别：");
		panel_1.add(label_3);

		booktype = new JComboBox();
		bookTypeModel = (DefaultComboBoxModel) booktype.getModel();
		// 从数据库中取出图书类别
		List list = null;
		try {
			list = ServiceFactory.getIBookTypeServiceInstance().list();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for (int i = 0; i < list.size(); i++) {
			BookType bktype = (BookType) list.get(i);
			toStringtype type = new toStringtype();
			type.setTypeid(bktype.getTypeId().toString());
			type.setTypename(bktype.getTypeName());
			bookTypeModel.addElement(type);
		}
		panel_1.add(booktype);

		final JLabel label_4 = new JLabel();
		label_4.setFont(new Font("宋体", Font.PLAIN, 20));
		label_4.setText("图书名称：");
		panel_1.add(label_4);

		nametxt = new JTextField();
		nametxt.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(nametxt);

		final JLabel label_7 = new JLabel();
		label_7.setFont(new Font("宋体", Font.PLAIN, 20));
		label_7.setText("作  者：");
		panel_1.add(label_7);

		authortxt = new JTextField();
		authortxt.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(authortxt);

		final JLabel label_9 = new JLabel();
		label_9.setFont(new Font("宋体", Font.PLAIN, 20));
		label_9.setText("出版社：");
		panel_1.add(label_9);

		publishtxt = new JFormattedTextField();
		publishtxt.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(publishtxt);

		final JLabel label_11 = new JLabel();
		label_11.setFont(new Font("宋体", Font.PLAIN, 20));
		label_11.setText("出版日期：");
		panel_1.add(label_11);

		final DatePicker datepick;
		datepick = getDatePicker();

		panel_1.add(datepick);

		final JLabel label_12 = new JLabel();
		label_12.setFont(new Font("宋体", Font.PLAIN, 20));
		label_12.setText("单  价：");
		panel_1.add(label_12);

		pricetxt = new JFormattedTextField();
		pricetxt.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(pricetxt);

		final JLabel label = new JLabel();
		label.setFont(new Font("宋体", Font.PLAIN, 20));
		label.setText("数  量：");
		panel_1.add(label);

		numbertxt = new JFormattedTextField();
		numbertxt.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				String numStr = "0123456789." + (char) 8;
				if (numStr.indexOf(e.getKeyChar()) < 0) {
					e.consume();
				}
			}
		});

		numbertxt.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(numbertxt);

		final JPanel panel_2 = new JPanel();
		panel_2.setBounds(15, 423, 450, 46);
		panel_2.setPreferredSize(new Dimension(450, 100));
		panel.add(panel_2);

		final JButton save = new JButton();
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// JOptionPane.showMessageDialog(f, "获取控件中的日期：" + datepick.getValue());
				// System.out.println(datepick.getValue());
				SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
				Date date1 = null;
				try {
					date1 = (Date) sdf.parse(datepick.getValue().toString());
					date = (Date) myfmt.parse(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date1));

				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (nametxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "图书名称文本框不可以为空");
					return;
				}
				Book book = null;
				// book=ServiceFactory.getIBookServiceInstance().

				if (authortxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "作者文本框不可以为空");
					return;
				}
				if (publishtxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "出版社文本框不可以为空");
					return;
				}

				if (pricetxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "单价文本框不可以为空");
					return;
				}
				if (numbertxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "数量文本框不可以为空");
					return;
				}

				String ISBN = ISBNtxt.getText().trim();

				// 分类
				Object selectedtype = booktype.getSelectedItem();
				if (selectedtype == null)
					return;
				toStringtype type = (toStringtype) selectedtype;
				Integer typeid = Integer.valueOf(type.getTypeid().toString().trim());
				String author = authortxt.getText().trim();
				String bookName = nametxt.getText().trim();
				String publish = publishtxt.getText().toString().trim();
				String prices = pricetxt.getText().trim();
				Integer amount = Integer.valueOf(numbertxt.getText().trim());
				book = null;
				StringBuffer buf = new StringBuffer().append("《").append(bookName).append("》");
				book = new Book(ISBN, typeid, buf.toString(), author, publish, date, Double.parseDouble(prices),
						amount);
				Boolean flag = false;
				try {
					flag = ServiceFactory.getIBookServiceInstance().insert(book);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (flag) {
					JOptionPane.showMessageDialog(null, "添加成功");
					ISBNtxt.setText("");
					nametxt.setText("");
					authortxt.setText("");
					publishtxt.setText("");
					pricetxt.setText("");
					numbertxt.setText("");
					return;
				} else {
					JOptionPane.showMessageDialog(null, "添加失败");
					return;
				}
			}
		});
		save.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(save);
		save.setText("保存");

		final JButton back = new JButton();
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ISBNtxt.setText("");
				nametxt.setText("");
				authortxt.setText("");
				publishtxt.setText("");
				pricetxt.setText("");
				numbertxt.setText("");
				doDefaultCloseAction();
			}
		});
		back.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(back);
		back.setText("返回");

		setVisible(true);
	}
}
