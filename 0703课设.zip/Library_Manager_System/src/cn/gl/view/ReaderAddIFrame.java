package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.Timer;

import cn.gl.factory.ServiceFactory;
import cn.gl.view.BookBorrowJFrame.TimeActionListener;
import cn.gl.vo.Reader;

import java.awt.Font;

/**
 * 本类为读者信息添加界面
 * 
 * @author Administrator
 *
 */
public class ReaderAddIFrame extends JInternalFrame {

	private JTextField readeId;
	private ButtonGroup buttonGroup = new ButtonGroup();
	private JFormattedTextField keepmoney;
	private JTextField tel;
	private JFormattedTextField maxnumber;
	private JFormattedTextField zctime;
	private JTextField zjnumber;
	private JTextField age;
	private JTextField readername;
	String[] array;
	SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

	private static ReaderAddIFrame readeraddfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized ReaderAddIFrame GetInstance() {
		if (readeraddfm == null) {
			readeraddfm = new ReaderAddIFrame();
		}
		return readeraddfm;
	}

	/**
	 * Create the frame
	 */
	public ReaderAddIFrame() {
		super();
		setTitle("读者相关信息添加");
		setIconifiable(true); // 设置窗体可最小化－－－必须
		setClosable(true); // 设置窗体可关闭－－－必须
							// 设置窗体标题－－－必须
		setBounds(100, 100, 493, 573);

		final JPanel panel = new JPanel();
		getContentPane().add(panel);
		panel.setLayout(null);

		final JPanel panel_1 = new JPanel();
		panel_1.setBounds(15, 64, 450, 403);
		panel_1.setPreferredSize(new Dimension(450, 200));
		panel.add(panel_1);
		panel_1.setLayout(null);

		final JLabel label_2 = new JLabel();
		label_2.setBounds(0, 2, 220, 31);
		label_2.setFont(new Font("宋体", Font.PLAIN, 20));
		label_2.setText("姓    名：");
		panel_1.add(label_2);

		readername = new JTextField();
		readername.setBounds(230, 2, 220, 31);
		readername.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(readername);

		final JLabel label_3 = new JLabel();
		label_3.setBounds(0, 48, 220, 31);
		label_3.setFont(new Font("宋体", Font.PLAIN, 20));
		label_3.setText("性    别：");
		panel_1.add(label_3);

		final JPanel label_13 = new JPanel();
		label_13.setBounds(230, 48, 220, 31);
		final FlowLayout flowLayout = new FlowLayout();
		flowLayout.setHgap(0);
		flowLayout.setVgap(0);
		label_13.setLayout(flowLayout);
		panel_1.add(label_13);

		final JRadioButton radioButton1 = new JRadioButton();
		radioButton1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_13.add(radioButton1);
		radioButton1.setSelected(true);
		buttonGroup.add(radioButton1);
		radioButton1.setText("男");

		final JRadioButton radioButton2 = new JRadioButton();
		radioButton2.setFont(new Font("宋体", Font.PLAIN, 20));
		label_13.add(radioButton2);
		buttonGroup.add(radioButton2);
		radioButton2.setText("女");

		final JLabel label_4 = new JLabel();
		label_4.setBounds(0, 94, 220, 31);
		label_4.setFont(new Font("宋体", Font.PLAIN, 20));
		label_4.setText("年    龄：");
		panel_1.add(label_4);

		age = new JTextField();
		age.setBounds(230, 94, 220, 31);
		age.setFont(new Font("宋体", Font.PLAIN, 20));
		age.addKeyListener(new NumberListener());
		panel_1.add(age);

		final JLabel label_7 = new JLabel();
		label_7.setBounds(0, 140, 220, 31);
		label_7.setFont(new Font("宋体", Font.PLAIN, 20));
		label_7.setText("证件号码：");
		panel_1.add(label_7);

		zjnumber = new JTextField();
		zjnumber.setBounds(230, 140, 220, 31);
		zjnumber.setFont(new Font("宋体", Font.PLAIN, 20));
		zjnumber.addKeyListener(new NumberListener());
		panel_1.add(zjnumber);

		final JLabel label_9 = new JLabel();
		label_9.setBounds(0, 186, 220, 31);
		label_9.setFont(new Font("宋体", Font.PLAIN, 20));
		label_9.setText("最大借书量：");
		panel_1.add(label_9);

		maxnumber = new JFormattedTextField();
		maxnumber.setBounds(230, 186, 220, 31);
		maxnumber.setFont(new Font("宋体", Font.PLAIN, 20));
		maxnumber.addKeyListener(new NumberListener());
		panel_1.add(maxnumber);
		maxnumber.setEditable(false);
		maxnumber.setText("5");

		SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date2 = new java.util.Date();
		date2.setDate(date2.getDate() + 365);

		final JLabel label_11 = new JLabel();
		label_11.setBounds(0, 232, 220, 31);
		label_11.setFont(new Font("宋体", Font.PLAIN, 20));
		label_11.setText("电    话：");
		panel_1.add(label_11);

		tel = new JTextField();
		tel.setBounds(230, 232, 220, 31);
		tel.setFont(new Font("宋体", Font.PLAIN, 20));
		tel.addKeyListener(new TelListener());

		panel_1.add(tel);

		final JLabel label_12 = new JLabel();
		label_12.setBounds(0, 278, 220, 31);
		label_12.setFont(new Font("宋体", Font.PLAIN, 20));
		label_12.setText("押    金：");
		panel_1.add(label_12);

		keepmoney = new JFormattedTextField();
		keepmoney.setBounds(230, 278, 220, 31);
		keepmoney.setFont(new Font("宋体", Font.PLAIN, 20));
		keepmoney.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				String numStr = "0123456789" + (char) 8;// 只允许输入数字与退格键
				if (numStr.indexOf(e.getKeyChar()) < 0) {
					e.consume();
				}
				if (keepmoney.getText().length() > 2 || keepmoney.getText().length() < 0) {
					e.consume();
				}
			}
		});
		panel_1.add(keepmoney);

		final JLabel label = new JLabel();
		label.setBounds(0, 324, 220, 31);
		label.setFont(new Font("宋体", Font.PLAIN, 20));
		label.setText("注册日期：");
		panel_1.add(label);

		zctime = new JFormattedTextField(myfmt.getDateInstance());
		zctime.setBounds(230, 324, 220, 31);
		zctime.setFont(new Font("宋体", Font.PLAIN, 20));
		zctime.setValue(new java.util.Date());
		panel_1.add(zctime);
		zctime.setEditable(false);
		zctime.setPreferredSize(new Dimension(0, 0));
		zctime.addActionListener(new TimeActionListener());
		zctime.setFocusable(false);

		final JLabel label_1 = new JLabel();
		label_1.setBounds(0, 370, 220, 31);
		label_1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_1.setText("读者编号：");
		panel_1.add(label_1);

		readeId = new JTextField();
		readeId.setBounds(230, 370, 220, 31);
		readeId.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(readeId);
		readeId.setEditable(false);
		try {
			Integer id = ServiceFactory.getIReaderServiceInstance().findLastId().getReaderId() + 1;
			readeId.setText(id.toString());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		final JPanel panel_2 = new JPanel();
		panel_2.setBounds(15, 482, 450, 46);
		panel_2.setPreferredSize(new Dimension(450, 100));
		panel.add(panel_2);

		final JButton save = new JButton();
		save.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(save);
		save.setText("保存");
		save.addActionListener(new ButtonAddListener(radioButton1));

		final JButton back = new JButton();
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doDefaultCloseAction();
			}
		});
		back.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(back);
		back.setText("返回");

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(ReaderAddIFrame.class.getResource("/source/readerAdd.jpg")));
		lblNewLabel.setBounds(0, 0, 477, 60);
		panel.add(lblNewLabel);

		setVisible(true);
	}

	class NumberListener extends KeyAdapter {
		public void keyTyped(KeyEvent e) {
			String numStr = "0123456789" + (char) 8;
			if (numStr.indexOf(e.getKeyChar()) < 0) {
				e.consume();
			}
		}
	}

	class ButtonAddListener implements ActionListener {
		private final JRadioButton button1;

		ButtonAddListener(JRadioButton button1) {
			this.button1 = button1;
		}

		public void actionPerformed(final ActionEvent e) {
			if (readername.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "读者姓名文本框不可为空");
				return;
			}
			if (age.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "读者年龄文本框不可为空");
				return;
			}

			if (zjnumber.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "证件号码文本框不可为空");
				return;
			}
			if (zjnumber.getText().length() != 18) {
				JOptionPane.showMessageDialog(null, "证件号码位数为18");
				return;
			}
			if (keepmoney.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "押金文本框不可为空");
				return;
			}

			if (tel.getText().length() == 0) {
				JOptionPane.showMessageDialog(null, "电话号码文本框不可为空");
				return;
			}
			if (tel.getText().length() > 11 || tel.getText().length() < 0) {
				JOptionPane.showMessageDialog(null, "电话号码位数小于11位");
				return;
			}

			String sex = "男";
			if (!button1.isSelected()) {
				sex = "女";
			}
			Reader reader = new Reader();
			try {
				Integer id = ServiceFactory.getIReaderServiceInstance().findLastId().getReaderId() + 1;
				reader.setReaderId(id);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			reader.setReaderName(readername.getText().toString().trim());
			reader.setReaderSex(sex);
			reader.setReaderAge(Integer.valueOf(age.getText().toString().trim()));
			reader.setReaderIdCard(zjnumber.getText().toString().trim());
			java.util.Date date = new java.util.Date();
			reader.setRegdate(date);
			reader.setReaderPhone(tel.getText().toString().trim());
			reader.setMaxNum(Integer.valueOf(maxnumber.getText().toString().trim()));
			reader.setKeepMoney(Double.parseDouble(keepmoney.getText().toString().trim()));
			Boolean flag = false;
			try {
				flag = ServiceFactory.getIReaderServiceInstance().insert(reader);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (flag) {
				JOptionPane.showMessageDialog(null, "添加成功！");
				return;
			} else {
				JOptionPane.showMessageDialog(null, "添加失败！");
				return;
			}

		}
	}

	class TelListener extends KeyAdapter {
		public void keyTyped(KeyEvent e) {
			String numStr = "0123456789-" + (char) 8;
			if (numStr.indexOf(e.getKeyChar()) < 0) {
				e.consume();
			}
		}
	}

	class TimeActionListener implements ActionListener {
		public TimeActionListener() {
			Timer t = new Timer(1000, this);
			t.start();
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			zctime.setText(myfmt.format(new java.util.Date()).toString());
		}
	}
}
