package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.Timer;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Book;
import cn.gl.vo.Borrow;
import cn.gl.vo.Reader;
import cn.gl.vo.User;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * 本类为还书界面
 * 
 * @author 高丽
 * @version V1.0
 */
@SuppressWarnings("serial")
public class BookReturnJFrame extends JInternalFrame {
	private User user = LoginJFrame.getUser();
	private static BookReturnJFrame returnfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized BookReturnJFrame GetInstance() {
		if (returnfm == null) {
			returnfm = new BookReturnJFrame();
		}
		return returnfm;
	}

	/**
	 * Launch the application.
	 */

	private JTable table;
	private JTextField operator;
	private JTextField todaydate;
	private JTextField fkmoney;
	private JTextField ccdays;
	private JTextField realdays;
	private JTextField borrowdays;
	private JTextField borrowDate;
	private JTextField readerISBN;
	private String[] columnNames = { "图书名称", "图书编号", "图书类别", "读者姓名", "读者编号", "借书时间", "归还时间" };
	DefaultTableModel model = new DefaultTableModel();
	SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	private String bookISBNs = null;
	private String readerISBNs = null;
	Double fine = 2.0;
	Date returndate = new java.util.Date();

	public void clearAll() {
		readerISBN.setText("");
		borrowdays.setText("");
		borrowDate.setText("");
		realdays.setText("");
		ccdays.setText("");
		fkmoney.setText("");
	}

	/**
	 * Create the frame.
	 */
	public BookReturnJFrame() {
		setClosable(true); // 设置窗体可关闭－－－必须
		setTitle("图书归还管理");
		setBounds(100, 100, 672, 647);

		final JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "基本信息", TitledBorder.DEFAULT_JUSTIFICATION,
				TitledBorder.DEFAULT_POSITION, null, null));
		panel.setPreferredSize(new Dimension(0, 270));
		getContentPane().add(panel, BorderLayout.NORTH);
		panel.setLayout(null);

		final JLabel label_4 = new JLabel();
		label_4.setBounds(151, 31, 100, 24);
		panel.add(label_4);
		label_4.setFont(new Font("宋体", Font.PLAIN, 20));
		label_4.setText("读者编号：");

		readerISBN = new JTextField();
		// 读者编号文本框键盘监听事件
		readerISBN.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				if (e.getKeyChar() == '\n') { // 判断在文本框是否输入回车。
					readerISBNs = readerISBN.getText().trim();
					Borrow borrow = null;
					Reader read = null;
					Book book = null;
					List<Borrow> list = new ArrayList<Borrow>();
					try {
						read = ServiceFactory.getIReaderServiceInstance().get(Integer.valueOf(readerISBNs));
						if (read == null) {
							JOptionPane.showMessageDialog(null, "此读者编号没有注册，查询输入读者编号是否有误！");
							return;
						}
						list = ServiceFactory.getIBorrowServiceInstance().getReader(Integer.valueOf(readerISBNs));

						if ((read != null) && (list.size() == 0)) {
							JOptionPane.showMessageDialog(null, "此读者没有未还书籍！");
							readerISBN.setText("");
							return;
						}
						for (int i = 0; i < list.size(); i++) {
							borrow = list.get(i);
							book = ServiceFactory.getIBookServiceInstance().get(borrow.getISBN());
							String str[] = new String[7];
							str[0] = book.getBookName();
							str[1] = book.getISBN();
							str[2] = book.getTypeId().toString() + "";
							str[3] = read.getReaderName();
							str[4] = read.getReaderId().toString();

							str[5] = myfmt.format(borrow.getBorrowDate());
							str[6] = myfmt.format(new java.util.Date());
							model.addRow(str);
							RowSorter sorter = new TableRowSorter(model);
							table.setRowSorter(sorter);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			}
		});
		readerISBN.setBounds(266, 28, 191, 30);
		panel.add(readerISBN);
		readerISBN.setFont(new Font("宋体", Font.PLAIN, 20));

		final JPanel panel_4 = new JPanel();
		panel_4.setBounds(15, 63, 626, 192);
		panel_4.setPreferredSize(new Dimension(450, 130));
		panel.add(panel_4);
		panel_4.setLayout(null);

		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(15, 5, 596, 172);
		scrollPane.setPreferredSize(new Dimension(450, 120));
		panel_4.add(scrollPane);

		table = new JTable();
		// 设置表格的鼠标监听事件
		table.addMouseListener(new MouseAdapter() {
			@SuppressWarnings({ "unused", "deprecation" })
			@Override
			public void mouseClicked(MouseEvent e) {
				java.util.Date date = new java.util.Date();

				String days1 = "7";
				int selRow = table.getSelectedRow();
				try {

					Borrow borrow = ServiceFactory.getIBorrowServiceInstance().getBook(
							Integer.valueOf(table.getValueAt(selRow, 4).toString().trim()),
							table.getValueAt(selRow, 2).toString().trim());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				borrowDate.setText(table.getValueAt(selRow, 5).toString().trim());
				int days2, days3;
				borrowdays.setText("7");
				days2 = date.getDate()
						- java.sql.Timestamp.valueOf(table.getValueAt(selRow, 5).toString().trim()).getDate();
				realdays.setText(String.valueOf(days2));
				days3 = days2 - Integer.parseInt(days1);
				if (days3 > 0) {
					ccdays.setText(String.valueOf(days3));
					fine = fine * days3;
					Double zfk = fine;
					fkmoney.setText(zfk + "元");
				} else {
					fine = 0.0;
					ccdays.setText("没有超过规定天数");
					fkmoney.setText("0");
				}
				bookISBNs = table.getValueAt(selRow, 1).toString().trim();
			}
		});
		scrollPane.setViewportView(table);
		model.setColumnIdentifiers(columnNames);
		table.setModel(model);

		final JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1);
		panel_1.setLayout(null);

		final JPanel panel_2 = new JPanel();
		panel_2.setBounds(15, 15, 613, 156);
		final GridLayout gridLayout_2 = new GridLayout(0, 4);
		gridLayout_2.setVgap(20);
		panel_2.setLayout(gridLayout_2);
		panel_2.setBorder(new TitledBorder(null, "罚款信息", TitledBorder.DEFAULT_JUSTIFICATION,
				TitledBorder.DEFAULT_POSITION, null, null));
		panel_2.setPreferredSize(new Dimension(250, 230));
		panel_1.add(panel_2);

		final JLabel label_11 = new JLabel();
		label_11.setFont(new Font("宋体", Font.PLAIN, 20));
		label_11.setText("借书日期：");
		panel_2.add(label_11);

		borrowDate = new JTextField();
		borrowDate.setEditable(false);

		panel_2.add(borrowDate);

		final JLabel label_12 = new JLabel();
		label_12.setFont(new Font("宋体", Font.PLAIN, 20));
		label_12.setText("规定天数：");
		panel_2.add(label_12);

		borrowdays = new JTextField();
		borrowdays.setEditable(false);
		panel_2.add(borrowdays);

		final JLabel label_13 = new JLabel();
		label_13.setFont(new Font("宋体", Font.PLAIN, 20));
		label_13.setText("实际天数：");
		panel_2.add(label_13);

		realdays = new JTextField();
		realdays.setEditable(false);
		panel_2.add(realdays);

		final JLabel label_14 = new JLabel();
		label_14.setFont(new Font("宋体", Font.PLAIN, 20));
		label_14.setText("超出天数：");
		panel_2.add(label_14);

		ccdays = new JTextField();
		ccdays.setEditable(false);
		panel_2.add(ccdays);

		final JLabel label_15 = new JLabel();
		label_15.setFont(new Font("宋体", Font.PLAIN, 20));
		label_15.setText("罚款金额：");
		panel_2.add(label_15);

		fkmoney = new JTextField();
		fkmoney.setEditable(false);
		panel_2.add(fkmoney);

		final JPanel panel_3 = new JPanel();
		panel_3.setBounds(15, 186, 613, 135);
		panel_3.setBorder(new TitledBorder(null, "系统信息", TitledBorder.DEFAULT_JUSTIFICATION,
				TitledBorder.DEFAULT_POSITION, null, null));
		panel_3.setPreferredSize(new Dimension(280, 230));
		panel_1.add(panel_3);
		panel_3.setLayout(null);

		final JPanel panel_7 = new JPanel();
		panel_7.setBounds(0, 28, 610, 29);
		final GridLayout gridLayout_3 = new GridLayout(0, 4);
		gridLayout_3.setVgap(35);
		panel_7.setLayout(gridLayout_3);
		panel_7.setPreferredSize(new Dimension(260, 90));
		panel_3.add(panel_7);

		final JLabel label_10_1 = new JLabel();
		label_10_1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_10_1.setText("当前时间：");
		panel_7.add(label_10_1);

		todaydate = new JTextField();
		todaydate.setEditable(false);
		todaydate.setPreferredSize(new Dimension(0, 0));
		todaydate.addActionListener(new TimeActionListener());
		todaydate.setFocusable(false);
		panel_7.add(todaydate);

		final JLabel label_11_1 = new JLabel();
		label_11_1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_11_1.setText("操作员：");
		panel_7.add(label_11_1);

		operator = new JTextField();
		operator.setText(user.getUserName());
		operator.setEditable(false);
		panel_7.add(operator);

		final JButton buttonback = new JButton();
		// 设置图书归还按钮事件
		buttonback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (readerISBNs == null) {
					JOptionPane.showMessageDialog(null, "请输入读者编号！");
					return;
				}

				if (table.getSelectedRow() == -1) {
					JOptionPane.showMessageDialog(null, "请选择所要归还的图书！");
					return;
				}

				boolean flag = false;
				try {
					// 查询借还表的此条记录
					bookISBNs = table.getValueAt(table.getSelectedRow(), 1).toString().trim();
					Borrow borrow = ServiceFactory.getIBorrowServiceInstance().getBook(Integer.valueOf(readerISBNs),
							bookISBNs); // 修改读者信息
					Reader read = ServiceFactory.getIReaderServiceInstance().get(borrow.getReaderId());
					read.setMaxNum(read.getMaxNum() + 1);
					read.setKeepMoney(read.getKeepMoney() - fine);
					ServiceFactory.getIReaderServiceInstance().update(read);
					// 修改书籍信息
					Book book = ServiceFactory.getIBookServiceInstance().get(borrow.getISBN());
					book.setAmount(book.getAmount() + 1);
					ServiceFactory.getIBookServiceInstance().update(book);
					// 将借还表的该条记录删除
					Date date = new java.util.Date();
					String todate = String.valueOf(myfmt.format(date));
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					// 增加1天
					cal.add(Calendar.DAY_OF_MONTH, 1);
					// Calendar转为Date类型
					returndate = cal.getTime();
					borrow.setReturnDate(returndate);
					borrow.setFine(fine);
					flag = ServiceFactory.getIBorrowServiceInstance().update(borrow);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (flag) {

					int selectedRow = table.getSelectedRow();
					model.removeRow(selectedRow);
					JOptionPane.showMessageDialog(null, "还书操作完成！");

				}
			}
		});
		buttonback.setFont(new Font("宋体", Font.PLAIN, 22));
		buttonback.setBounds(131, 86, 150, 29);
		buttonback.setText("图书归还");
		panel_3.add(buttonback);

		JButton buttonback_1 = new JButton();
		buttonback_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearAll();
				doDefaultCloseAction();
			}
		});
		buttonback_1.setText("退出");
		buttonback_1.setFont(new Font("宋体", Font.PLAIN, 22));
		buttonback_1.setBounds(337, 86, 150, 29);
		panel_3.add(buttonback_1);
		setVisible(true);
		//
	}

	class TimeActionListener implements ActionListener {
		public TimeActionListener() {
			Timer t = new Timer(1000, this);
			t.start();
		}

		public void actionPerformed(ActionEvent ae) {
			todaydate.setText(myfmt.format(new java.util.Date()).toString());
		}
	}

	class CloseActionListener implements ActionListener { // 添加关闭按钮的事件监听器
		public void actionPerformed(final ActionEvent e) {
			doDefaultCloseAction();
		}
	}

}
