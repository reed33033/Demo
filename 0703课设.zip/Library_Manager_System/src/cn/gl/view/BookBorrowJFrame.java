package cn.gl.view;

import javax.swing.JInternalFrame;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;
import cn.gl.vo.Borrow;
import cn.gl.vo.Reader;
import cn.gl.vo.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;

import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JSpinner;

/**
 * 本类为借书窗体
 * 
 * @author 高丽
 * @version V1.0
 */
@SuppressWarnings("serial")
public class BookBorrowJFrame extends JInternalFrame {
	private static BookBorrowJFrame borrowfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例
	private User user = LoginJFrame.getUser();
	private final JTextField operator;
	private JTextField todaydate;
	private JTable table;
	private JTextField price;
	private JTextField bookType;
	private JTextField bookName;
	private JTextField bookISBN;
	private JTextField keepMoney;
	private JTextField number;
	private JTextField readerName;
	private JTextField readerISBN;
	private String[] columnNames = { "书籍编号", "借书日期", "应还日期", "读者编号" };
	DefaultTableModel model = new DefaultTableModel();
	SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	Date date;
	Date date1;

	public static synchronized BookBorrowJFrame GetInstance() {
		if (borrowfm == null) {
			borrowfm = new BookBorrowJFrame();
		}
		return borrowfm;
	}

	/**
	 * Launch the application.
	 */

	public void clearAll() {
		bookName.setText("");
		bookType.setText("");
		price.setText("");
		readerName.setText("");
		number.setText("");
		keepMoney.setText("");
		readerISBN.setText("");
		bookISBN.setText("");
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		while (model.getRowCount() > 0) {
			model.removeRow(model.getRowCount() - 1);
		}
	}

	/**
	 * Create the frame.
	 */
	public BookBorrowJFrame() {
		setClosable(true);

		setTitle("图书借阅管理");
		setBounds(100, 100, 635, 685);

		final JPanel panel = new JPanel();
		getContentPane().add(panel);
		panel.setLayout(null);

		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(15, 15, 573, 319);
		scrollPane.setPreferredSize(new Dimension(400, 70));
		panel.add(scrollPane);

		table = new JTable();
		table.setFont(new Font("宋体", Font.PLAIN, 20));
		scrollPane.setViewportView(table);
		model.setColumnIdentifiers(columnNames);

		table.setModel(model);

		final JPanel panel_1 = new JPanel();
		panel_1.setPreferredSize(new Dimension(0, 180));
		getContentPane().add(panel_1, BorderLayout.NORTH);
		panel_1.setLayout(null);

		final JSplitPane splitPane = new JSplitPane();
		splitPane.setBounds(15, 15, 564, 150);
		panel_1.add(splitPane);
		splitPane.setDividerLocation(280);
		final JPanel panel_3 = new JPanel();
		final GridLayout gridLayout_3 = new GridLayout(0, 2);
		gridLayout_3.setVgap(10);
		panel_3.setLayout(gridLayout_3);
		panel_3.setPreferredSize(new Dimension(240, 110));
		splitPane.setLeftComponent(panel_3);

		final JLabel label = new JLabel();
		label.setFont(new Font("宋体", Font.PLAIN, 20));
		label.setText("读者编号：");
		panel_3.add(label);

		readerISBN = new JTextField();
		// 读者编号框输入后的添加监听事件
		readerISBN.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				String ISBN;
				Reader reader;
				// 判断有没有输入回车
				if (e.getKeyChar() == '\n') {
					ISBN = readerISBN.getText().trim();
					reader = null;
					try {
						reader = ServiceFactory.getIReaderServiceInstance().get(Integer.valueOf(ISBN));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if (reader == null && !ISBN.isEmpty()) {
						JOptionPane.showMessageDialog(null, "此读者编号没有注册，查询输入读者编号是否有误！");
					} else if (ISBN.isEmpty()) {
						JOptionPane.showMessageDialog(null, "请输入读者编号！");
					}

					if (reader != null) {
						readerName.setText(reader.getReaderName());
						number.setText(reader.getMaxNum().toString());
						keepMoney.setText(reader.getKeepMoney().toString());
					}
				}
			}
		});
		readerISBN.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_3.add(readerISBN);

		final JLabel label_1 = new JLabel();
		panel_3.add(label_1);
		label_1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_1.setText("读者姓名：");

		readerName = new JTextField();
		panel_3.add(readerName);
		readerName.setFont(new Font("宋体", Font.PLAIN, 20));
		readerName.setEditable(false);

		final JLabel label_2 = new JLabel();
		panel_3.add(label_2);
		label_2.setFont(new Font("宋体", Font.PLAIN, 20));
		label_2.setText("可借数量：");

		number = new JTextField();
		panel_3.add(number);
		number.setFont(new Font("宋体", Font.PLAIN, 20));
		number.setEditable(false);

		final JLabel label_4 = new JLabel();
		panel_3.add(label_4);
		label_4.setFont(new Font("宋体", Font.PLAIN, 20));
		label_4.setText("押    金：");

		keepMoney = new JTextField();
		panel_3.add(keepMoney);
		keepMoney.setFont(new Font("宋体", Font.PLAIN, 20));
		keepMoney.setEditable(false);

		final JPanel panel_4 = new JPanel();
		final GridLayout gridLayout_1 = new GridLayout(0, 2);
		gridLayout_1.setVgap(10);
		panel_4.setLayout(gridLayout_1);
		panel_4.setPreferredSize(new Dimension(240, 110));
		splitPane.setRightComponent(panel_4);

		final JLabel label_5 = new JLabel();
		label_5.setFont(new Font("宋体", Font.PLAIN, 20));
		label_5.setText("书籍编号：");
		panel_4.add(label_5);

		bookISBN = new JTextField();
		bookISBN.addKeyListener(new KeyAdapter() {
			@SuppressWarnings("unused")
			@Override
			public void keyTyped(KeyEvent e) {
				String ISBN;
				Book book;
				BookType booktype;
				Reader read;
				if (e.getKeyChar() == '\n') { // 判断在文本框是否输入回车。
					if (readerISBN.getText().trim().length() != 0 && bookISBN.getText().trim().length() != 0) {
						try {
							ISBN = bookISBN.getText().trim();
							book = ServiceFactory.getIBookServiceInstance().get(ISBN);
							booktype = ServiceFactory.getIBookTypeServiceInstance().get(book.getTypeId());
							read = ServiceFactory.getIReaderServiceInstance()
									.get(Integer.valueOf(readerISBN.getText().trim()));

							// 设置书籍文本内设置的内容
							bookName.setText(book.getBookName());
							bookType.setText(booktype.getTypeName());
							price.setText(String.valueOf(book.getUnitPrice()));

							if (!ISBN.isEmpty() && (read == null)) {
								JOptionPane.showMessageDialog(null, "此读者编号没有注册，查询输入读者编号是否有误！");
								return;
							}
							if ((book == null) && (!ISBN.isEmpty())) {
								JOptionPane.showMessageDialog(null, "本图书馆没有此书，查询输入图书编号是否有误！");
								return;
							}
							if ((book != null) && book.getAmount() <= 0) {
								JOptionPane.showMessageDialog(null, "此书已借完！");
								return;
							}
							if (Integer.parseInt(number.getText().trim()) <= 0) {
								JOptionPane.showMessageDialog(null, "借书量已经超过最大借书量！");
								clearAll();
								return;
							}
							if (read.getKeepMoney() <= 0) {
								JOptionPane.showMessageDialog(null, "押金不足，请充值押金！");
								clearAll();
								return;
							} else {

								String str[] = new String[4];
								str[0] = bookISBN.getText().trim();
								// SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

								date = new java.util.Date();
								str[1] = String.valueOf(myfmt.format(date));

								Calendar cal = Calendar.getInstance();
								cal.setTime(date);
								// 增加7天
								cal.add(Calendar.DAY_OF_MONTH, 7);
								// Calendar转为Date类型
								date1 = cal.getTime();

								str[2] = String.valueOf(myfmt.format(date1));

								str[3] = readerISBN.getText().trim();

								model.addRow(str);
								RowSorter sorter = new TableRowSorter(model);
								table.setRowSorter(sorter);
							}
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						number.setText(String.valueOf(Integer.parseInt(number.getText().trim()) - 1));
					} else
						JOptionPane.showMessageDialog(null, "请输入读者编号！");
				}

			}
		});
		bookISBN.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_4.add(bookISBN);

		final JLabel label_6 = new JLabel();
		label_6.setFont(new Font("宋体", Font.PLAIN, 20));
		label_6.setText("书籍名称：");
		panel_4.add(label_6);

		bookName = new JTextField();
		bookName.setEditable(false);
		panel_4.add(bookName);

		final JLabel label_7 = new JLabel();
		label_7.setFont(new Font("宋体", Font.PLAIN, 20));
		label_7.setText("书籍类别：");
		panel_4.add(label_7);

		bookType = new JTextField();
		bookType.setFont(new Font("宋体", Font.PLAIN, 20));
		bookType.setEditable(false);
		panel_4.add(bookType);

		final JLabel label_8 = new JLabel();
		label_8.setFont(new Font("宋体", Font.PLAIN, 20));
		label_8.setText("书籍价格：");
		panel_4.add(label_8);

		price = new JTextField();
		price.setFont(new Font("宋体", Font.PLAIN, 20));
		price.setEditable(false);
		panel_4.add(price);

		final JPanel panel_2 = new JPanel();
		panel_2.setPreferredSize(new Dimension(0, 100));
		getContentPane().add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(null);

		final JButton buttonBorrow = new JButton();
		buttonBorrow.setFont(new Font("宋体", Font.PLAIN, 20));
		buttonBorrow.setBounds(125, 62, 159, 29);
		panel_2.add(buttonBorrow);
		buttonBorrow.setText("借出图书");
		buttonBorrow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				boolean flag = false;

				String bookISBNs;
				String operatorId = user.getUserName();
				String readerISBNs = readerISBN.getText().trim();
				double fine = 0;

				try {
					for (int i = 0; i < table.getRowCount(); i++) {
						// 将借书记录存入借还信息表
						bookISBNs = table.getValueAt(i, 0).toString().trim();
						Borrow borrow = new Borrow(bookISBNs, operatorId, Integer.valueOf(readerISBNs), date, date,
								fine);
						flag = ServiceFactory.getIBorrowServiceInstance().insert(borrow);
						// 借书后的图书在图书信息表中休息
						Book book = ServiceFactory.getIBookServiceInstance().get(bookISBNs);
						book.setAmount(book.getAmount() - 1);
						ServiceFactory.getIBookServiceInstance().update(book);
						// 借书后的读者在读者信息表中修改
						Reader read = ServiceFactory.getIReaderServiceInstance().get(Integer.valueOf(readerISBNs));
						read.setMaxNum(read.getMaxNum() - 1);
						ServiceFactory.getIReaderServiceInstance().update(read);
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				if (flag) {
					JOptionPane.showMessageDialog(null, "图书借阅完成！");
					clearAll();
					doDefaultCloseAction();
				} else {
					JOptionPane.showMessageDialog(null, "图书借阅失败！");
					return;
				}
			}
		});

		operator = new JTextField(user.getUserName());
		operator.setBounds(404, 16, 172, 32);
		panel_2.add(operator);
		operator.setEditable(false);

		final JLabel label_11 = new JLabel();
		label_11.setFont(new Font("宋体", Font.PLAIN, 20));
		label_11.setBounds(309, 15, 80, 32);
		panel_2.add(label_11);
		label_11.setText("操作员：");

		todaydate = new JTextField();
		todaydate.setBounds(125, 16, 169, 32);
		panel_2.add(todaydate);
		todaydate.setEditable(false);
		todaydate.setPreferredSize(new Dimension(0, 0));
		todaydate.addActionListener(new TimeActionListener());
		todaydate.setFocusable(false);

		final JLabel label_9 = new JLabel();
		label_9.setFont(new Font("宋体", Font.PLAIN, 20));
		label_9.setBounds(15, 15, 100, 32);
		panel_2.add(label_9);
		label_9.setText("当前时间：");

		JButton buttonBorrow_1 = new JButton();
		buttonBorrow_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clearAll();
				doDefaultCloseAction();
			}
		});
		buttonBorrow_1.setText("退出");
		buttonBorrow_1.setFont(new Font("宋体", Font.PLAIN, 20));
		buttonBorrow_1.setBounds(337, 62, 159, 29);
		panel_2.add(buttonBorrow_1);

		setVisible(true);

	}

	class TimeActionListener implements ActionListener {
		public TimeActionListener() {
			Timer t = new Timer(1000, this);
			t.start();
		}

		public void actionPerformed(ActionEvent ae) {
			todaydate.setText(myfmt.format(new java.util.Date()).toString());
		}
	}
}
