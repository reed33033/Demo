package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.beans.PropertyVetoException;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 本类为主界面
 * @author 高丽
 *@version V1.0
 */
public class MainJFrame {

	private JFrame frame;
	private JDesktopPane desktopPane;
	
	public JFrame getFrame() {
		return frame;
		
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainJFrame window = new MainJFrame();
					window.frame.setVisible(false);
					new LoginJFrame().setVisible(true);					
					//window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainJFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings("serial")
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("图书管理系统");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage(MainJFrame.class.getResource("/source/logo.png")));
		frame.setBounds(350, 100, 1350, 900);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		desktopPane = new JDesktopPane() {
			@Override
			public void paintComponent(Graphics g) {// 重绘面板背景
				// 创建一个未初始化的图像图标，参考API
				ImageIcon icon = new ImageIcon("src" + File.separator + "source" + File.separator + "mainImg.jpg");
				// 绘制指定图像中已缩放到适合指定矩形内部的图像，参考API
				g.drawImage(icon.getImage(), 0, 0, this.getWidth(), this.getHeight(), this);
			}
		};
		frame.getContentPane().add(desktopPane, BorderLayout.CENTER);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setToolTipText("");
		frame.getContentPane().add(menuBar, BorderLayout.NORTH);

		JMenu mnNewMenu = new JMenu("");
		mnNewMenu.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/jcsjcd.jpg")));
		mnNewMenu.setMnemonic('n');
		menuBar.add(mnNewMenu);

		JMenu mnNewMenu_1 = new JMenu("读者信息管理");
		mnNewMenu.add(mnNewMenu_1);

		JMenuItem mntmNewMenuItem = new JMenuItem("读者信息添加");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(ReaderAddIFrame.GetInstance());
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem);

		JMenuItem mntmNewMenuItem_3 = new JMenuItem("读者修改与删除");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(ReaderModAndDel.GetInstance());
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_2 = new JMenu("图书信息管理");
		mnNewMenu.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("图书信息添加");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookAddIFrame.GetInstance());
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_4);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("图书修改与删除");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookModAndDel.GetInstance());
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_5);
		
		JMenu mnNewMenu_3 = new JMenu("图书类别管理");
		mnNewMenu.add(mnNewMenu_3);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("图书类别添加");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookTypeAddIFrame.GetInstance());
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("图书类别修改");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookTypeModAndDelIFrame.GetInstance());
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_2);
		
		JMenu mnNewMenu_4 = new JMenu("");
		mnNewMenu_4.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/jyglcd.jpg")));
		menuBar.add(mnNewMenu_4);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("图书借阅");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookBorrowJFrame.GetInstance());
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_7);
		
		JMenuItem mntmNewMenuItem_8 = new JMenuItem("图书归还");
		mntmNewMenuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookReturnJFrame.GetInstance());
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_8);
		
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("图书查询");
		mntmNewMenuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookFindIFrame.GetInstance());
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_9);
		
		JMenu menu = new JMenu("");
		menu.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/jcwhcd.jpg")));
		menuBar.add(menu);
		
		JMenuItem mntmNewMenuItem_11 = new JMenuItem("用户添加");
		mntmNewMenuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(UserAddIFrame.GetInstance());
			}
		});
		menu.add(mntmNewMenuItem_11);
		
		JMenuItem mntmNewMenuItem_12 = new JMenuItem("用户删除与修改");
		mntmNewMenuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(UserDelAndModIFrame.GetInstance());
			}
		});
		menu.add(mntmNewMenuItem_12);
		
		JMenuItem mntmNewMenuItem_6 = new JMenuItem("用户查询");
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(UserFindIFrame.GetInstance());
			}
		});
		menu.add(mntmNewMenuItem_6);

		JToolBar toolBar = new JToolBar();
		toolBar.setBounds(0, 0, 1928, 50);
		desktopPane.add(toolBar);

		JButton btnNewButton = new JButton();
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookAddIFrame.GetInstance());
			}
		});
		btnNewButton.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/bookAddtb.jpg")));
		btnNewButton.setHideActionText(true);
		btnNewButton.setToolTipText("图书信息添加");

		toolBar.add(btnNewButton);

		toolBar.addSeparator(new Dimension(10, 45));

		JButton btnNewButton_1 = new JButton();
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookModAndDel.GetInstance());
			}
		});
		
		btnNewButton_1.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/bookModiAndDeltb.jpg")));
		btnNewButton_1.setToolTipText("图书修改");
		toolBar.add(btnNewButton_1);

		toolBar.addSeparator(new Dimension(10, 45));

		JButton btnNewButton_2 = new JButton();
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookTypeAddIFrame.GetInstance());
			}
		});
		
		btnNewButton_2.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/bookTypeAddtb.jpg")));
		btnNewButton_2.setToolTipText("图书类别添加");
		toolBar.add(btnNewButton_2);
		
		toolBar.addSeparator(new Dimension(10, 45));
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookBorrowJFrame.GetInstance());
			}
		});
		button.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/bookBorrowtb.jpg")));
		button.setToolTipText("图书借阅");
		toolBar.add(button);
		
		toolBar.addSeparator(new Dimension(10, 45));
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(BookFindIFrame.GetInstance());
			}
		});
		button_1.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/bookOrdertb.jpg")));
		button_1.setToolTipText("图书查询");
		toolBar.add(button_1);
		
		toolBar.addSeparator(new Dimension(10, 45));
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(UserAddIFrame.GetInstance());
			}
		});
		btnNewButton_3.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/newbookChecktb.jpg")));
		btnNewButton_3.setToolTipText("添加用户");
		toolBar.add(btnNewButton_3);
		
		toolBar.addSeparator(new Dimension(10, 45));
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(ReaderAddIFrame.GetInstance());
			}
		});
		btnNewButton_4.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/readerAddtb.jpg")));
		btnNewButton_4.setToolTipText("添加读者信息");
		toolBar.add(btnNewButton_4);
		
		toolBar.addSeparator(new Dimension(10, 45));
		JButton btnNewButton_5 = new JButton("");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displayJInternalFrame(ReaderModAndDel.GetInstance());
			}
		});
		btnNewButton_5.setIcon(new ImageIcon(MainJFrame.class.getResource("/source/readerModiAndDeltb.jpg")));
		btnNewButton_5.setToolTipText("读者信息修改");
		toolBar.add(btnNewButton_5);
		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);// 窗口最大化
	}
	
	public void displayJInternalFrame(JInternalFrame jif) {
		JInternalFrame jifl[] = desktopPane.getAllFrames();
		// 判断顶层面板中是否已经存在需要调用的子窗体
		if (jifl.length > 0)
			return;
		desktopPane.add(jif);
		jif.setVisible(true);
		UiUtil.setFrameCenter(jif);
		try {
			jif.setSelected(true);
		} catch (PropertyVetoException e1) {
			e1.printStackTrace();
		}
	}
}
