package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;

/**
 * 本类为登录界面
 * 
 * @author 高丽
 * @version V1.0
 */
public class LoginJFrame extends JFrame {

	private JPanel contentPane;
	private JTextField userNameTxt;
	private JPasswordField passwordTxt;
	private static User user;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginJFrame frame = new LoginJFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginJFrame() {
		setTitle("登录");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("图书管理系统");
		lblNewLabel.setBounds(92, 38, 282, 67);
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 25));
		lblNewLabel.setIcon(new ImageIcon(LoginJFrame.class.getResource("/source/logo.png")));
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("用户名：");
		lblNewLabel_1.setIcon(new ImageIcon(LoginJFrame.class.getResource("/source/userName.png")));
		lblNewLabel_1.setBounds(102, 131, 103, 21);
		contentPane.add(lblNewLabel_1);

		userNameTxt = new JTextField();
		userNameTxt.setBounds(208, 128, 124, 27);
		contentPane.add(userNameTxt);
		userNameTxt.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("密码：");
		lblNewLabel_2.setIcon(new ImageIcon(LoginJFrame.class.getResource("/source/password.png")));
		lblNewLabel_2.setBounds(102, 182, 81, 21);
		contentPane.add(lblNewLabel_2);

		passwordTxt = new JPasswordField();
		passwordTxt.setBounds(208, 179, 124, 27);
		passwordTxt.setEchoChar('*');// 设置密码框的回显字符
		contentPane.add(passwordTxt);

		JButton btnNewButton = new JButton("登录");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = userNameTxt.getText();
				String password = new String(passwordTxt.getPassword());
				if (userName.equals("")) {
					JOptionPane.showMessageDialog(null, "用户名不能为空！");
					return;
				}
				if (password.equals("")) {
					JOptionPane.showMessageDialog(null, "密码不能为空！");
					return;
				}
				try {
					user = ServiceFactory.getIUserServiceInstance().userLogin(userName, password);
				} catch (Exception e1) {
					userNameTxt.setText("");
					passwordTxt.setText("");
				}
				if (user != null) {
					try {
						new MainJFrame().getFrame().setVisible(true);
						LoginJFrame.this.setVisible(false);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				} else {
					JOptionPane.showMessageDialog(null, "用户名或密码错误！");
					userNameTxt.setText("");
					passwordTxt.setText("");
				}
			}
		});
		btnNewButton.setIcon(new ImageIcon(LoginJFrame.class.getResource("/source/login.png")));
		btnNewButton.setBounds(177, 233, 95, 29);
		contentPane.add(btnNewButton);

		// 设置JFrame居中显示
		this.setLocationRelativeTo(null);
	}

	public static User getUser() {
		return user;
	}

	public static void setUser(User user) {
		LoginJFrame.user = user;
	}

}
