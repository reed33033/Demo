package cn.gl.view;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.User;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * 本类为用户添加界面
 * @author 高丽
 *@version V1.0
 */
public class UserAddIFrame extends JInternalFrame {
	private JTextField usernametxt;
	private JTextField passwordtxt;
	

	/**
	 * Launch the application.
	 */
	private static UserAddIFrame useraddfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized UserAddIFrame GetInstance() {
		if (useraddfm == null) {
			useraddfm = new UserAddIFrame();
		}
		return useraddfm;
	}

	/**
	 * Create the frame.
	 */
	public UserAddIFrame() {
		setClosable(true);
		setTitle("用户信息添加");
		setBounds(100, 100, 454, 242);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.SOUTH);
		
		JButton btnNewButton = new JButton("添加");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String username=usernametxt.getText().toString().trim();
				String password=passwordtxt.getText().toString().trim();
				User user=new User(username,password);
				boolean flag=false;
				try {
					flag = ServiceFactory.getIUserServiceInstance().insert(user);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(flag) {
					JOptionPane.showMessageDialog(null, "添加成功！");
					usernametxt.setText("");
					passwordtxt.setText("");
					return;
				}else {
					JOptionPane.showMessageDialog(null, "添加失败！");
				}
			}
		});
		btnNewButton.setFont(new Font("宋体", Font.PLAIN, 23));
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("取消");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				usernametxt.setText("");
				passwordtxt.setText("");
				doDefaultCloseAction();
			}
		});
		btnNewButton_1.setFont(new Font("宋体", Font.PLAIN, 23));
		panel.add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("用户名：");
		lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 21));
		lblNewLabel.setBounds(50, 15, 99, 35);
		panel_1.add(lblNewLabel);
		
		usernametxt = new JTextField();
		usernametxt.setFont(new Font("宋体", Font.PLAIN, 21));
		usernametxt.setBounds(171, 15, 180, 40);
		panel_1.add(usernametxt);
		usernametxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("密码：");
		lblNewLabel_1.setFont(new Font("宋体", Font.PLAIN, 21));
		lblNewLabel_1.setBounds(50, 89, 99, 35);
		panel_1.add(lblNewLabel_1);
		
		passwordtxt = new JTextField();
		passwordtxt.setFont(new Font("宋体", Font.PLAIN, 21));
		passwordtxt.setColumns(10);
		passwordtxt.setBounds(171, 89, 180, 40);
		panel_1.add(passwordtxt);

	}
}
