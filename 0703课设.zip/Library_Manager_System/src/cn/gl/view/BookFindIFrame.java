package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.AbstractListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;

import javax.swing.JComboBox;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 本类为图书查询界面
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class BookFindIFrame extends JInternalFrame {

	private static BookFindIFrame bookfindfm = null;// 定义子窗体为私有
	private JTextField choicetxt;
	private JComboBox choice;
	DefaultTableModel model = new DefaultTableModel();
	JScrollPane scrollPane, scrollPane_1;
	JButton findbtn;
	private int currentPage = 1;
	private int pageSize = 13;
	private int lastPage;
	JLabel lblNewLabel;
	private int size = 0;
	private String bookfind[] = { "编号", "分类", "名称", "作者", "出版社", "出版日期", "单价", "数量" };
	private JTable table_1;
	private JTable table;
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized BookFindIFrame GetInstance() {
		if (bookfindfm == null) {
			bookfindfm = new BookFindIFrame();
		}
		return bookfindfm;
	}

	@SuppressWarnings("unchecked")
	public void showTable(List list, int currentPage) {
		model.setRowCount(0);// 清除原有行
		setCurrentPage(currentPage);
		List<Book> list1 = null;
		list1 = findBook(list, currentPage, pageSize);
		for (int row = 0; row < list1.size(); row++) // 获得数据
		{
			Vector rowV = new Vector();
			Book book = (Book) list1.get(row);
			rowV.add(book.getISBN()); // 数据
			BookType type = null;
			try {
				type = ServiceFactory.getIBookTypeServiceInstance().get(book.getTypeId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			rowV.add(type.getTypeName());
			rowV.add(book.getBookName());
			rowV.add(book.getAuthor());
			rowV.add(book.getPublish());
			rowV.add((book.getPublishDate()));
			rowV.add((book.getUnitPrice()));
			rowV.add((book.getAmount()));
			model.addRow(rowV);
		}

		// table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //关闭表格列的自动调整功能。
		table_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // 单选
		table_1.setSelectionBackground(Color.YELLOW);
		table_1.setSelectionForeground(Color.RED);
		table_1.setRowHeight(30);
	}

	private Object[][] getselect(List list) {
		Object[][] s = new Object[list.size()][8];
		for (int i = 0; i < list.size(); i++) {
			Book book = (Book) list.get(i);
			s[i][0] = book.getISBN();
			String booktypename = null;
			try {
				booktypename = ServiceFactory.getIBookTypeServiceInstance().get(book.getTypeId()).getTypeName();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			s[i][1] = booktypename;
			s[i][2] = book.getBookName();
			s[i][3] = book.getAuthor();
			s[i][4] = book.getPublish();
			s[i][5] = book.getPublishDate();
			s[i][6] = book.getUnitPrice();
			s[i][7] = book.getAmount();
		}
		return s;

	}

	private Object[] getselectid(List list) {
		Object[] ids = new Object[list.size()];
		for (int i = 0; i < list.size(); i++) {
			Book book = null;
			book = (Book) list.get(i);
			ids[i] = book.getISBN();
		}
		return ids;
	}

	public static List<Book> findBook(List list, int currentPage, int pageSize) {

		List<Book> list1 = new ArrayList();
		int listLength = list.size();
		if (currentPage < 1) {
			currentPage = 1;
		}
		int startIndex = (currentPage - 1) * pageSize;
		int endIndex = startIndex + pageSize;

		if (endIndex >= listLength) {
			endIndex = listLength;
		}
		list1 = list.subList(startIndex, endIndex);
		return list1;
	}

	public int getLastPage() {
		return lastPage;
	}

	public void setLastPage(int lastPage) {
		this.lastPage = lastPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public BookFindIFrame() {
		setTitle("图书查询");
		setResizable(true);
		setClosable(true);
		setBounds(100, 100, 650, 583);
		getContentPane().setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, 634, 542);
		getContentPane().add(tabbedPane);

		JPanel panel1 = new JPanel();
		tabbedPane.addTab("条件查询", null, panel1, null);
		panel1.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 15, 623, 69);
		panel.setBorder(new TitledBorder(null, "\u8BF7\u9009\u62E9\u67E5\u8BE2\u6761\u4EF6", TitledBorder.LEADING,
				TitledBorder.TOP, null, null));
		panel1.add(panel);

		choice = new JComboBox();
		choice.setFont(new Font("宋体", Font.PLAIN, 22));
		String[] array = { "图书名称", "图书编号" };
		for (int i = 0; i < array.length; i++) {
			choice.addItem(array[i]);

		}
		panel.add(choice);

		choicetxt = new JTextField();
		choicetxt.setFont(new Font("宋体", Font.PLAIN, 22));
		panel.add(choicetxt);
		choicetxt.setColumns(23);

		findbtn = new JButton("查询");
		findbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = choice.getSelectedItem().toString().trim();
				Book book = null;
				List<Book> list = new ArrayList<Book>();
				if (name.equals("图书编号")) {
					try {
						book = ServiceFactory.getIBookServiceInstance().get(choicetxt.getText().toString().trim());
						list.add(book);
						Object[][] results = getselect(list);
						if (results == null) {
							JOptionPane.showMessageDialog(null, "此书籍不存在！");
							return;
						} else {
							table = new JTable(results, bookfind);
							scrollPane.setViewportView(table);
						}
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else if (name.equals("图书名称")) {

					try {
						list = (ServiceFactory.getIBookServiceInstance()
								.findbook(choicetxt.getText().toString().trim()));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					if (list.size() == 0) {
						JOptionPane.showMessageDialog(null, "此书籍不存在！");
						return;
					} else {
						Object[][] results = getselect(list);
						table = new JTable(results, bookfind);
						scrollPane.setViewportView(table);
					}
				}
			}
		});
		findbtn.setFont(new Font("宋体", Font.PLAIN, 23));
		panel.add(findbtn);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 87, 623, 357);
		panel1.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));

		scrollPane = new JScrollPane();
		panel_1.add(scrollPane, BorderLayout.CENTER);

		table = new JTable();
		scrollPane.setViewportView(table);

		JButton btnNewButton_2 = new JButton("退出");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doDefaultCloseAction();
			}
		});
		btnNewButton_2.setBounds(228, 459, 126, 35);
		btnNewButton_2.setFont(new Font("宋体", Font.PLAIN, 22));
		panel1.add(btnNewButton_2);

		JPanel panel2 = new JPanel();
		tabbedPane.addTab("显示图书全部信息", null, panel2, null);
		panel2.setLayout(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 15, 629, 427);
		panel2.add(panel_2);
		panel_2.setLayout(new BorderLayout(0, 0));

		scrollPane_1 = new JScrollPane();
		panel_2.add(scrollPane_1, BorderLayout.CENTER);
		List list = null;
		// Object[][] results=null;
//		try {
//			results = getselect(ServiceFactory.getIBookServiceInstance().getAll());
//			list=ServiceFactory.getIBookServiceInstance().getAll();
//			 if(list.size()%pageSize==0){
//		        	setLastPage(list.size()/getPageSize());
//		        }else{
//		        	setLastPage(list.size()/getPageSize()+1);
//		        }
//		} catch (Exception e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}

		try {
			// results = getselect(ServiceFactory.getIBookServiceInstance().getAll());
			list = ServiceFactory.getIBookServiceInstance().getAll();
			// size=ServiceFactory.getIBookServiceInstance().getCount("ISBN", "");
			// list=ServiceFactory.getIBookServiceInstance().getAll();
			if (list.size() % pageSize == 0) {
				setLastPage(list.size() / getPageSize());
			} else {
				setLastPage(list.size() / getPageSize() + 1);
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		// Map<String,Object> map=ServiceFactory.getIBookServiceInstance().listSplit(1,
		// 5, "ISBN", "");
		model = new DefaultTableModel(bookfind, 0);

		table_1 = new JTable(model);
		// table_1 = new JTable(results,bookfind);
		RowSorter sorter = new TableRowSorter(model);
		table_1.setRowSorter(sorter);
		scrollPane_1.setViewportView(table_1);
		showTable(list, currentPage);

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 459, 629, 48);
		panel2.add(panel_3);

		JButton btnNewButton_2_1 = new JButton("首页");
		btnNewButton_2_1.setBounds(174, 5, 99, 35);
		btnNewButton_2_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_1.addActionListener(new MyTable());
		panel_3.setLayout(null);

		lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(15, 12, 154, 21);
		panel_3.add(lblNewLabel);
		panel_3.add(btnNewButton_2_1);

		JButton btnNewButton_2_1_1 = new JButton("上一页");
		btnNewButton_2_1_1.setBounds(276, 4, 108, 35);
		showTable(list, currentPage);
		btnNewButton_2_1_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_1_1.addActionListener(new MyTable());
		panel_3.add(btnNewButton_2_1_1);

		JButton btnNewButton_2_1_1_1 = new JButton("下一页");
		btnNewButton_2_1_1_1.setBounds(387, 4, 108, 35);
		btnNewButton_2_1_1_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_1_1_1.addActionListener(new MyTable());
		panel_3.add(btnNewButton_2_1_1_1);

		JButton btnNewButton_2_1_1_2 = new JButton("尾页");
		btnNewButton_2_1_1_2.setBounds(501, 4, 99, 35);
		btnNewButton_2_1_1_2.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_1_1_2.addActionListener(new MyTable());
		panel_3.add(btnNewButton_2_1_1_2);

	}

	class MyTable implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			List list = null;
			try {
				list = ServiceFactory.getIBookServiceInstance().getAll();
				int page = list.size() / getPageSize() + 1;
				lblNewLabel.setText("总共" + page + "页|当前第" + 1 + "页");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (e.getActionCommand().equals("首页")) {
				showTable(list, 1);
			}

			if (e.getActionCommand().equals("上一页")) {
				int page = getCurrentPage() + 1;
				int page1 = list.size() / getPageSize() + 1;
				lblNewLabel.setText("总共" + page1 + "页|当前第" + page + "页");
				if (getCurrentPage() <= 1) {
					setCurrentPage(2);

				}
				showTable(list, getCurrentPage() - 1);
			}

			if (e.getActionCommand().equals("下一页")) {
				int page1 = list.size() / getPageSize() + 1;
				int page = getCurrentPage() + 1;
				lblNewLabel.setText("总共" + page1 + "页|当前第" + page + "页");
				if (getCurrentPage() < getLastPage()) {
					showTable(list, getCurrentPage() + 1);
				} else {
					lblNewLabel.setText("总共" + page1 + "页|当前第" + getLastPage() + "页");
					showTable(list, getLastPage());
				}
			}

			if (e.getActionCommand().equals("尾页")) {
				int page1 = list.size() / getPageSize() + 1;
				lblNewLabel.setText("总共" + page1 + "页|当前第" + getLastPage() + "页");
				showTable(list, getLastPage());

			}
		}
	}
}
