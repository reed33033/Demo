package cn.gl.view;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import cn.gl.factory.ServiceFactory;
import cn.gl.view.ReaderAddIFrame.ButtonAddListener;
import cn.gl.view.ReaderAddIFrame.NumberListener;
import cn.gl.view.ReaderAddIFrame.TelListener;
import cn.gl.view.ReaderAddIFrame.TimeActionListener;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;
import cn.gl.vo.Reader;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * 本类为读者修改和删除界面
 * @author 高丽
 *@version V1.0
 */
public class ReaderModAndDel extends JInternalFrame {

	/**
	 * Launch the application.
	 */

	private static ReaderModAndDel readmdfm = null;// 定义子窗体为私有
	private JTextField choicetxt;
	private JComboBox choice;
	DefaultTableModel model = new DefaultTableModel();
	JScrollPane scrollPane, scrollPane_1;
	JButton findbtn;
	private String[] columnNames = { "读者编号", "读者名称","性别","年龄","身份证号","注册日期","电话号码","最大借书量","押金"};
	private JTextField readeId;
	private ButtonGroup buttonGroup = new ButtonGroup();
	private JFormattedTextField keepmoney;
	private JTextField tel;
	private JFormattedTextField maxnumber;
	private JFormattedTextField zctime;
	private JTextField zjnumber;
	private JTextField age;
	private JTextField readername;
	String [] array;	
	SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	private JTextField chiocetxt;
	private JTable table;
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized ReaderModAndDel GetInstance() {
		if (readmdfm == null) {
			readmdfm = new ReaderModAndDel();
		}
		return readmdfm;
	}
	
	private Object[][] getFileStates(List list){
		Object[][] bt=new Object[list.size()][columnNames.length];
		for(int i=0;i<list.size();i++){
			Reader read=(Reader)list.get(i);
			bt[i][0]=read.getReaderId();
			bt[i][1]=read.getReaderName();
			bt[i][2]=read.getReaderSex();
			bt[i][3]=read.getReaderAge();
			bt[i][4]=read.getReaderIdCard();
			bt[i][5]=read.getRegdate();
			bt[i][6]=read.getReaderPhone();
			bt[i][7]=read.getMaxNum();
			bt[i][8]=read.getKeepMoney();
		}
		return bt;
	}

	


	public ReaderModAndDel() {
		setTitle("读者相关信息添加");
		setIconifiable(true);							// 设置窗体可最小化－－－必须
		setClosable(true);								// 设置窗体可关闭－－－必须
														// 设置窗体标题－－－必须
		setBounds(100, 100, 619, 692);

		final JPanel panel = new JPanel();
		getContentPane().add(panel);
		panel.setLayout(null);

		final JPanel panel_1 = new JPanel();
		panel_1.setBounds(15, 348, 575, 227);
		panel_1.setPreferredSize(new Dimension(450, 200));
		panel.add(panel_1);
		panel_1.setLayout(null);

		final JLabel label_2 = new JLabel();
		label_2.setBounds(0, 2, 100, 31);
		label_2.setFont(new Font("宋体", Font.PLAIN, 20));
		label_2.setText("姓    名：");
		panel_1.add(label_2);

		readername = new JTextField();
		readername.setBounds(95, 2, 170, 31);
		readername.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(readername);

		final JLabel label_3 = new JLabel();
		label_3.setBounds(280, 2, 111, 31);
		label_3.setFont(new Font("宋体", Font.PLAIN, 20));
		label_3.setText("性    别：");
		panel_1.add(label_3);

		final JPanel label_13 = new JPanel();
		label_13.setBounds(374, 2, 186, 31);
		final FlowLayout flowLayout = new FlowLayout();
		flowLayout.setHgap(0);
		flowLayout.setVgap(0);
		label_13.setLayout(flowLayout);
		panel_1.add(label_13);

		final JRadioButton radioButton1 = new JRadioButton();
		radioButton1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_13.add(radioButton1);
		radioButton1.setSelected(true);
		buttonGroup.add(radioButton1);
		radioButton1.setText("男");

		final JRadioButton radioButton2 = new JRadioButton();
		radioButton2.setFont(new Font("宋体", Font.PLAIN, 20));
		label_13.add(radioButton2);
		buttonGroup.add(radioButton2);
		radioButton2.setText("女");		


		final JLabel label_4 = new JLabel();
		label_4.setBounds(0, 45, 100, 31);
		label_4.setFont(new Font("宋体", Font.PLAIN, 20));
		label_4.setText("年    龄：");
		panel_1.add(label_4);

		age = new JTextField();
		age.setBounds(93, 48, 172, 31);
		age.setFont(new Font("宋体", Font.PLAIN, 20));
		age.addKeyListener(new NumberListener());
		panel_1.add(age);
	

		final JLabel label_7 = new JLabel();
		label_7.setBounds(272, 48, 105, 31);
		label_7.setFont(new Font("宋体", Font.PLAIN, 20));
		label_7.setText("证件号码：");
		panel_1.add(label_7);

		zjnumber = new JTextField();
		zjnumber.setBounds(374, 48, 186, 31);
		zjnumber.setFont(new Font("宋体", Font.PLAIN, 20));
		zjnumber.addKeyListener(new NumberListener());
		panel_1.add(zjnumber);
		zjnumber.setEditable(false);



		final JLabel label_9 = new JLabel();
		label_9.setBounds(0, 91, 132, 31);
		label_9.setFont(new Font("宋体", Font.PLAIN, 20));
		label_9.setText("最大借书量：");
		panel_1.add(label_9);
		
		
		maxnumber = new JFormattedTextField();
		maxnumber.setBounds(121, 94, 141, 31);
		maxnumber.setFont(new Font("宋体", Font.PLAIN, 20));
		maxnumber.addKeyListener(new NumberListener());
		panel_1.add(maxnumber);
		maxnumber.setText("5");

		SimpleDateFormat myfmt=new SimpleDateFormat("yyyy-MM-dd");
		java.util.Date date2 = new java.util.Date();
		date2.setDate(date2.getDate() + 365);

		final JLabel label_11 = new JLabel();
		label_11.setBounds(272, 94, 100, 31);
		label_11.setFont(new Font("宋体", Font.PLAIN, 20));
		label_11.setText("电    话：");
		panel_1.add(label_11);
		

		tel = new JTextField();
		tel.setBounds(374, 94, 186, 31);
		tel.setFont(new Font("宋体", Font.PLAIN, 20));
		tel.addKeyListener(new TelListener());

		panel_1.add(tel);

		final JLabel label_12 = new JLabel();
		label_12.setBounds(0, 137, 111, 31);
		label_12.setFont(new Font("宋体", Font.PLAIN, 20));
		label_12.setText("押    金：");
		panel_1.add(label_12);
		
		keepmoney = new JFormattedTextField();
		keepmoney.setBounds(95, 137, 170, 31);
		keepmoney.setFont(new Font("宋体", Font.PLAIN, 20));
		keepmoney.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				String numStr="0123456789"+(char)8;//只允许输入数字与退格键
				if(numStr.indexOf(e.getKeyChar())<0){
					e.consume();
				}
				if(keepmoney.getText().length()>2||keepmoney.getText().length()<0){
					e.consume();
				}
			}
		});
		panel_1.add(keepmoney);

		final JLabel label = new JLabel();
		label.setBounds(272, 147, 100, 31);
		label.setFont(new Font("宋体", Font.PLAIN, 20));
		label.setText("注册日期：");
		panel_1.add(label);

		
		zctime = new JFormattedTextField();
		zctime.setBounds(374, 147, 186, 31);
		zctime.setFont(new Font("宋体", Font.PLAIN, 20));
		zctime.setValue(new java.util.Date());
		panel_1.add(zctime);
		zctime.setEditable(false);
		zctime.setPreferredSize(new Dimension(0, 0));

		final JLabel label_1 = new JLabel();
		label_1.setBounds(0, 183, 111, 31);
		label_1.setFont(new Font("宋体", Font.PLAIN, 20));
		label_1.setText("读者编号：");
		panel_1.add(label_1);

		readeId = new JTextField();
		readeId.setBounds(95, 183, 170, 31);
		readeId.setFont(new Font("宋体", Font.PLAIN, 20));
		panel_1.add(readeId);
		readeId.setEditable(false);
		try {
			Integer id=ServiceFactory.getIReaderServiceInstance().findLastId().getReaderId()+1;
		readeId.setText(id.toString());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		final JPanel panel_2 = new JPanel();
		panel_2.setBounds(82, 590, 450, 46);
		panel_2.setPreferredSize(new Dimension(450, 100));
		panel.add(panel_2);
		
		JButton save_1 = new JButton();
		save_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id=readeId.getText().toString().trim();
				Boolean flag=false;
				Set<Integer> all = new HashSet<Integer>();
				all.add(Integer.valueOf(id));
				try {
					flag = ServiceFactory.getIReaderServiceInstance().delete(all);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(flag){
					JOptionPane.showMessageDialog(null, "删除成功");
					Object[][] results=null;
					try {
						results = getFileStates(ServiceFactory.getIReaderServiceInstance().findAll());
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, "删除失败");
						e1.printStackTrace();
					}
					
					DefaultTableModel model=new DefaultTableModel();					
					table.setModel(model);
					model.setDataVector(results, columnNames);
					//setAllColumnWidth(table,215);
				}
			}
		});
		save_1.setText("删除");
		save_1.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(save_1);

		final JButton save = new JButton();
		save.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(save);
		save.setText("修改");
		save.addActionListener(new ButtonAddListener(radioButton1));
		

		final JButton back = new JButton();
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doDefaultCloseAction();
			}
		});
		back.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(back);
		back.setText("返回");
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(ReaderModAndDel.class.getResource("/source/readerModiAndDel.jpg")));
		lblNewLabel.setBounds(0, 0, 590, 60);
		panel.add(lblNewLabel);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(10, 115, 578, 212);
		panel.add(panel_3);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane_2 = new JScrollPane();
		panel_3.add(scrollPane_2, BorderLayout.CENTER);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String id,name,age1,sex,card,number,phone,money,date;
				int selRow = table.getSelectedRow();
				id = table.getValueAt(selRow, 0).toString().trim();
				name = table.getValueAt(selRow, 1).toString().trim();
				if(table.getValueAt(selRow, 2).toString().trim().equals("男")) {
					radioButton1.setSelected(true);
				}else {
					radioButton2.setSelected(true);}
				age1=table.getValueAt(selRow, 3).toString().trim();
				card=table.getValueAt(selRow, 4).toString().trim();
				date=table.getValueAt(selRow, 5).toString().trim();
				phone=table.getValueAt(selRow, 6).toString().trim();
				number=table.getValueAt(selRow, 7).toString().trim();
				money=table.getValueAt(selRow, 8).toString().trim();
				readername.setText(name);	
				readeId.setText(id);
				age.setText(age1);
				zjnumber.setText(card);
				zctime.setText(date);
				tel.setText(phone);
				maxnumber.setText(number);
				keepmoney.setText(money);				
				
			}
		});
		scrollPane_2.setViewportView(table);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(15, 64, 573, 36);
		panel.add(panel_4);
		
		JComboBox comboBox = new JComboBox();
		String[] array={"读者编号","读者名称"};
		for(int i=0;i<array.length;i++){
			comboBox.addItem(array[i]);
			
		}
		panel_4.add(comboBox);
		
		chiocetxt = new JTextField();
		panel_4.add(chiocetxt);
		chiocetxt.setColumns(10);
		
		JButton btnNewButton = new JButton("查询");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=comboBox.getSelectedItem().toString().trim();
				if(name.equals("读者编号")){	
					List<Reader> list=new ArrayList<Reader>();
					Object[][] results=null;
					Reader read=null;
					try {
					Integer readerid=Integer.valueOf(chiocetxt.getText().toString().trim());	
					
						read=ServiceFactory.getIReaderServiceInstance().get(readerid);
						list.add(read);
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "读者编号不存在！");
						return;
					}
					if(read==null) {
						JOptionPane.showMessageDialog(null, "读者编号不存在！");
						return;
					}else {
						results = getFileStates(list);
						DefaultTableModel model=new DefaultTableModel();					
						table.setModel(model);
						model.setDataVector(results, columnNames);
					}
				}else if(name.equals("读者名称")){
				List<Reader> list=new ArrayList<Reader>();
				Object[][] results=null;
				list=null;
				try {
					list=ServiceFactory.getIReaderServiceInstance().get(chiocetxt.getText().toString().trim());
					
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(list.size()==0) {
					JOptionPane.showMessageDialog(null, "读者不存在！");
					return;
				}else{
					results = getFileStates(list);
					DefaultTableModel model=new DefaultTableModel();					
					table.setModel(model);
					model.setDataVector(results, columnNames);
				}
			}
			}
		});
		panel_4.add(btnNewButton);

		setVisible(true);
	}
	class NumberListener extends KeyAdapter {
		public void keyTyped(KeyEvent e) {
			String numStr="0123456789"+(char)8;
			if(numStr.indexOf(e.getKeyChar())<0){
				e.consume();
			}
		}
	}
	class ButtonAddListener implements ActionListener {
		private final JRadioButton button1;
		ButtonAddListener(JRadioButton button1) {
			this.button1 = button1;
		}
		public void actionPerformed(final ActionEvent e) {			
			if(readername.getText().length()==0){
				JOptionPane.showMessageDialog(null, "读者姓名文本框不可为空");
				return;
			}
			if(age.getText().length()==0){
				JOptionPane.showMessageDialog(null, "读者年龄文本框不可为空");
				return;
			}
			
			if(zjnumber.getText().length()==0){
				JOptionPane.showMessageDialog(null, "证件号码文本框不可为空");
				return;
			}
			if(zjnumber.getText().length()!=18){
				JOptionPane.showMessageDialog(null, "证件号码位数为18");
				return;
			}
			if(keepmoney.getText().length()==0){
				JOptionPane.showMessageDialog(null, "押金文本框不可为空");
				return;
			}
			
			if(tel.getText().length()==0){
				JOptionPane.showMessageDialog(null, "电话号码文本框不可为空");
				return;
			}
			if(tel.getText().length()>11||tel.getText().length()<0){
				JOptionPane.showMessageDialog(null, "电话号码位数小于11位");
				return;
			}
			
			String sex="男";
			if(!button1.isSelected()){
				sex="女";}
			Reader reader=new Reader();
			Integer id=100000;
			try {
				id=ServiceFactory.getIReaderServiceInstance().findLastId().getReaderId();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			reader.setReaderName(readername.getText().toString().trim());
			reader.setReaderSex(sex);
			reader.setReaderAge(Integer.valueOf(age.getText().toString().trim()));
			reader.setReaderIdCard(zjnumber.getText().toString().trim());
			java.util.Date date = new java.util.Date();
			reader.setRegdate(date);
			reader.setReaderPhone(tel.getText().toString().trim());
			reader.setMaxNum(Integer.valueOf(maxnumber.getText().toString().trim()));
			reader.setKeepMoney(Double.parseDouble(keepmoney.getText().toString().trim()));
			reader.setReaderId(id);
			Boolean flag=false;
			try {
				flag=ServiceFactory.getIReaderServiceInstance().update(reader);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(flag) {
				JOptionPane.showMessageDialog(null, "修改成功！");
				return;
			}else {
				JOptionPane.showMessageDialog(null, "修改失败！");
				return;
			}
			

			
		}
	}
	class TelListener extends KeyAdapter {
		public void keyTyped(KeyEvent e) {
			String numStr="0123456789-"+(char)8;
			if(numStr.indexOf(e.getKeyChar())<0){
				e.consume();
			}
		}
	}
	class TimeActionListener implements ActionListener {
		public TimeActionListener() {
			Timer t = new Timer(1000, this);
			t.start();
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			zctime.setText(myfmt.format(new java.util.Date()).toString());			
		}
	}
}
