package cn.gl.view;
/**
 * 用户删除和修改界面
 */
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.User;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * 本类为用户删除和修改界面
 * @author 高丽
 *@version V1.0
 */
public class UserDelAndModIFrame extends JInternalFrame {
	private JTextField usernametxt;
	private JTextField usernametxt2;
	private JTextField passwordtxt;
	private JTable table;
	private String[] str;
	
	private Object[][] getFileStates(List list){
		String[] str = { "用户名", "密码" };
		Object[][]users=new Object[list.size()][str.length];
		for(int i=0;i<list.size();i++){
			User user=(User)list.get(i);
			users[i][0]=user.getUserName();
			users[i][1]=user.getPassword();
		}
		return users;
	         		
	}
	
	public void setAllColumnWidth(JTable table,int width){
        Enumeration<TableColumn> cms = table.getColumnModel().getColumns();
        while(cms.hasMoreElements()){
            cms.nextElement().setPreferredWidth(width);
        }
    }

	/**
	 * Launch the application.
	 */
	private static UserDelAndModIFrame userdm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized UserDelAndModIFrame GetInstance() {
		if (userdm == null) {
			userdm = new UserDelAndModIFrame();
		}
		return userdm;
	}

	/**
	 * Create the frame.
	 */
	public UserDelAndModIFrame() {
		setClosable(true);
		setTitle("用户删除与修改");
		setBounds(100, 100, 483, 452);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 464, 56);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("用户名：");
		lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel.setBounds(15, 15, 90, 26);
		panel.add(lblNewLabel);
		
		usernametxt = new JTextField();
		usernametxt.setFont(new Font("宋体", Font.PLAIN, 22));
		usernametxt.setBounds(100, 15, 244, 26);
		panel.add(usernametxt);
		usernametxt.setColumns(10);
		
		
		JButton btnNewButton = new JButton("查询");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user=null;
				try {
					user=ServiceFactory.getIUserServiceInstance().get(usernametxt.getText().toString().trim());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(user==null) {
					JOptionPane.showMessageDialog(null, "此用户不存在！");
					return;
				}else {
					List<User> list=new ArrayList<User>();
					list.add(user);
					Object[][] results=null;
					try {
						results = getFileStates(list);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					DefaultTableModel model=new DefaultTableModel();					
					table.setModel(model);
					model.setDataVector(results, str);
					 RowSorter sorter = new TableRowSorter(model);
				        table.setRowSorter(sorter);
					setAllColumnWidth(table,215);
				}
				
			}
		});
		btnNewButton.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton.setBounds(350, 15, 99, 29);
		panel.add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 61, 464, 190);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(15, 15, 434, 160);
		panel_1.add(scrollPane);
		
		Object[][] results=null;
		try {
			results = getFileStates(ServiceFactory.getIUserServiceInstance().list());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		str = new String[]{"用户名", "密码"};
		table = new JTable(results,str);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		setAllColumnWidth(table,215);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent e) {
				
				String username,password;
				int selRow = table.getSelectedRow();
				username = table.getValueAt(selRow, 0).toString().trim();
				password = table.getValueAt(selRow, 1).toString().trim();
				usernametxt2.setText(username);
				passwordtxt.setText(password);				
			}
		});
		scrollPane.setViewportView(table);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 257, 464, 89);
		getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("用户名：");
		lblNewLabel_1.setBounds(31, 8, 88, 26);
		panel_2.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("宋体", Font.PLAIN, 22));
		
		usernametxt2 = new JTextField();
		usernametxt2.setBounds(124, 5, 276, 32);
		panel_2.add(usernametxt2);
		usernametxt2.setFont(new Font("宋体", Font.PLAIN, 22));
		usernametxt2.setColumns(10);
		usernametxt2.setEditable(false);
		
		JLabel lblNewLabel_1_1 = new JLabel("密码：");
		lblNewLabel_1_1.setBounds(29, 48, 66, 26);
		panel_2.add(lblNewLabel_1_1);
		lblNewLabel_1_1.setFont(new Font("宋体", Font.PLAIN, 22));
		
		passwordtxt = new JTextField();
		passwordtxt.setBounds(124, 45, 276, 32);
		panel_2.add(passwordtxt);
		passwordtxt.setFont(new Font("宋体", Font.PLAIN, 22));
		passwordtxt.setColumns(10);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 356, 464, 61);
		getContentPane().add(panel_3);
		
		JButton modbtn = new JButton("修改");
		modbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
							
				if(passwordtxt.getText().length()==0){
					JOptionPane.showMessageDialog(null, "密码不能为空");
					return;
				}				
		
			String name=usernametxt2.getText().toString().trim();
			String password=passwordtxt.getText().toString().trim();
		    User user=new User(name,password);
		    //System.out.println(name+password);
			Boolean flag=false;
			try {
				flag = ServiceFactory.getIUserServiceInstance().update(user);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		if(flag){

			JOptionPane.showMessageDialog(null, "修改成功");
			Object[][] results=null;
			try {
				results = getFileStates(ServiceFactory.getIUserServiceInstance().list());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			DefaultTableModel model=new DefaultTableModel();					
			table.setModel(model);
			model.setDataVector(results, str);
			setAllColumnWidth(table,215);
}
			}
			});
		modbtn.setFont(new Font("宋体", Font.PLAIN, 23));
		panel_3.add(modbtn);
		
		JButton delbtn = new JButton("删除");
		delbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=usernametxt2.getText().toString().trim();
				Boolean flag=false;
				try {
					flag = ServiceFactory.getIUserServiceInstance().delete(name);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(flag){
					JOptionPane.showMessageDialog(null, "删除成功");
					Object[][] results=null;
					try {
						results = getFileStates(ServiceFactory.getIUserServiceInstance().list());
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, "删除失败");
						e1.printStackTrace();
					}
					
					DefaultTableModel model=new DefaultTableModel();					
					table.setModel(model);
					model.setDataVector(results, str);
					setAllColumnWidth(table,215);
				}
			}
		});
		delbtn.setFont(new Font("宋体", Font.PLAIN, 23));
		panel_3.add(delbtn);
		
		JButton exitbtn = new JButton("退出");
		exitbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				usernametxt.setText("");
				passwordtxt.setText("");
				doDefaultCloseAction();
			}
		});
		exitbtn.setFont(new Font("宋体", Font.PLAIN, 23));
		panel_3.add(exitbtn);

	}
}
