package cn.gl.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.RowSorter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;
import cn.gl.vo.User;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.awt.event.ActionEvent;

/**
 * 图书类别修改和删除界面
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class BookTypeModAndDelIFrame extends JInternalFrame {
	private JTextField typeIdtxt;
	private JTextField typeNametxt;
	private JTextField choicetxt;
	private JTable table;
	private String[] columnNames = { "图书类型编号", "图书类型名称" };
	DefaultTableModel model = new DefaultTableModel();

	/**
	 * Launch the application.
	 */
	private static BookTypeModAndDelIFrame btmdfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized BookTypeModAndDelIFrame GetInstance() {
		if (btmdfm == null) {
			btmdfm = new BookTypeModAndDelIFrame();
		}
		return btmdfm;
	}

	private Object[][] getFileStates(List list) {
		Object[][] bt = new Object[list.size()][columnNames.length];
		for (int i = 0; i < list.size(); i++) {
			BookType booktype = (BookType) list.get(i);
			bt[i][0] = booktype.getTypeId();
			bt[i][1] = booktype.getTypeName();
		}
		return bt;

	}

	public void setAllColumnWidth(JTable table, int width) {
		Enumeration<TableColumn> cms = table.getColumnModel().getColumns();
		while (cms.hasMoreElements()) {
			cms.nextElement().setPreferredWidth(width);
		}
	}

	/**
	 * Create the frame.
	 */
	public BookTypeModAndDelIFrame() {
		setClosable(true);
		setTitle("图书类别修改与查询");
		setBounds(100, 100, 509, 608);
		getContentPane().setLayout(null);

		final JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(0, 0, 494, 91);
		lblNewLabel.setIcon(new ImageIcon(BookTypeModAndDelIFrame.class.getResource("/source/booktypemodify.jpg")));
		getContentPane().add(lblNewLabel);

		JLabel label = new JLabel("图书类别编号：");
		label.setBounds(25, 411, 154, 37);
		label.setFont(new Font("宋体", Font.PLAIN, 21));
		getContentPane().add(label);

		typeIdtxt = new JTextField();
		typeIdtxt.setBounds(194, 414, 285, 33);
		typeIdtxt.setFont(new Font("宋体", Font.PLAIN, 20));
		getContentPane().add(typeIdtxt);
		typeIdtxt.setColumns(10);
		typeIdtxt.setEditable(false);

		JLabel label_1 = new JLabel("图书类名名称：");
		label_1.setBounds(25, 463, 154, 37);
		label_1.setFont(new Font("宋体", Font.PLAIN, 21));
		getContentPane().add(label_1);

		typeNametxt = new JTextField();
		typeNametxt.setBounds(194, 466, 285, 33);
		typeNametxt.setFont(new Font("宋体", Font.PLAIN, 20));
		typeNametxt.setColumns(10);
		getContentPane().add(typeNametxt);

		JButton modbtn = new JButton("修改");
		modbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = typeNametxt.getText().toString().trim();
				Integer id = Integer.valueOf(typeIdtxt.getText().toString().trim());
				BookType type = new BookType(id, name);
				Boolean flag = false;
				try {
					flag = ServiceFactory.getIBookTypeServiceInstance().update(type);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (flag) {
					JOptionPane.showMessageDialog(null, "修改成功！");
					List<BookType> list = new ArrayList<BookType>();
					Object[][] results = null;
					try {
						list = ServiceFactory.getIBookTypeServiceInstance().list();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					results = getFileStates(list);
					DefaultTableModel model = new DefaultTableModel();
					table.setModel(model);
					model.setDataVector(results, columnNames);
					RowSorter sorter = new TableRowSorter(model);
					table.setRowSorter(sorter);
					setAllColumnWidth(table, 215);
					return;
				}
			}
		});
		modbtn.setBounds(85, 515, 126, 37);
		modbtn.setFont(new Font("宋体", Font.PLAIN, 22));
		getContentPane().add(modbtn);

		JComboBox choice = new JComboBox();
		choice.setFont(new Font("宋体", Font.PLAIN, 18));
		choice.setBounds(10, 106, 105, 37);
		String[] array = { "类别编号", "类别名称" };
		for (int i = 0; i < array.length; i++) {
			choice.addItem(array[i]);

		}
		getContentPane().add(choice);

		choicetxt = new JTextField();
		choicetxt.setFont(new Font("宋体", Font.PLAIN, 20));
		choicetxt.setColumns(10);
		choicetxt.setBounds(120, 106, 271, 33);
		getContentPane().add(choicetxt);

		JButton button_1 = new JButton("查询");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = choice.getSelectedItem().toString().trim();
				if (name.equals("类别编号")) {
					List<BookType> list = new ArrayList<BookType>();
					Object[][] results = null;
					BookType booktype = null;
					try {
						Integer id = Integer.valueOf(choicetxt.getText().toString().trim());
						booktype = ServiceFactory.getIBookTypeServiceInstance().get(id);
						list.add(booktype);
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "此书籍类别不存在！");
						return;
					}
					if (booktype == null) {
						JOptionPane.showMessageDialog(null, "此书籍类别不存在！");
						return;
					} else {
						typeIdtxt.setText(String.valueOf(booktype.getTypeId()));
						typeNametxt.setText(booktype.getTypeName());
						results = getFileStates(list);
						DefaultTableModel model = new DefaultTableModel();
						table.setModel(model);
						model.setDataVector(results, columnNames);
						setAllColumnWidth(table, 215);
					}
				} else if (name.equals("类别名称")) {
					List<BookType> list = new ArrayList<BookType>();
					Object[][] results = null;
					try {
						list = ServiceFactory.getIBookTypeServiceInstance().get(choicetxt.getText().toString().trim());
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if (list.size() == 0) {
						JOptionPane.showMessageDialog(null, "此书籍类别不存在！");
						return;
					} else {
						results = getFileStates(list);
						DefaultTableModel model = new DefaultTableModel();
						table.setModel(model);
						model.setDataVector(results, columnNames);
						RowSorter sorter = new TableRowSorter(model);
						table.setRowSorter(sorter);
						setAllColumnWidth(table, 215);
					}
				}
			}
		});
		button_1.setFont(new Font("宋体", Font.PLAIN, 22));
		button_1.setBounds(396, 106, 83, 37);
		getContentPane().add(button_1);

		JPanel panel = new JPanel();
		panel.setBounds(25, 166, 452, 229);
		getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));

		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane, BorderLayout.CENTER);

		Object[][] results = null;
		try {
			results = getFileStates(ServiceFactory.getIBookTypeServiceInstance().list());
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		table = new JTable(results, columnNames);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		setAllColumnWidth(table, 215);
		scrollPane.setViewportView(table);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(final MouseEvent e) {

				String id, name;
				int selRow = table.getSelectedRow();
				id = table.getValueAt(selRow, 0).toString().trim();
				name = table.getValueAt(selRow, 1).toString().trim();
				typeIdtxt.setText(id);
				typeNametxt.setText(name);
			}
		});

		JButton exitbtn = new JButton("退出");
		exitbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				typeIdtxt.setText("");
				typeNametxt.setText("");
				doDefaultCloseAction();
			}
		});
		exitbtn.setFont(new Font("宋体", Font.PLAIN, 22));
		exitbtn.setBounds(275, 515, 126, 37);
		getContentPane().add(exitbtn);

	}
}
