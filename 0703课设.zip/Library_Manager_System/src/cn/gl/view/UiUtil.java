/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.gl.view;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;

/**
 * 专门做界面效果的类
 *
 * @author 高丽
 * @version V1.0
 */
public class UiUtil {

    private UiUtil() {
    }

    //修改窗体的图标
    public static void setFrameImage(JFrame jf) {
        //获取工具类对象
        //public static Toolkit getDefaultToolkit():获取默认工具包。 
        Toolkit tk = Toolkit.getDefaultToolkit();

        //根据路径获取图片
        Image i = tk.getImage("src\\cn\\itcast\\resource\\jjcc.jpg");

        //给窗体设置图片
        jf.setIconImage(i);
    }

    //设置窗体居中
    public static void setFrameCenter(JInternalFrame jif) {
        /*
         思路：
         A:获取屏幕的宽和高
         B:获取窗体的宽和高
         C:(用屏幕的宽-窗体的宽)/2，(用屏幕的高-窗体的高)/2作为窗体的新坐标。
         */
    	Toolkit tk=Toolkit.getDefaultToolkit();//获取默认工具包。
		Dimension d=tk.getScreenSize();//获取屏幕尺寸
		int swidth=d.width;//获取屏幕宽度
		int sheight=d.height;//获取屏幕高度
		int x=(swidth-jif.getWidth()*2)/2;//(屏幕宽度-子窗体宽度)/2
		int y=(sheight-jif.getHeight())/2;//(屏幕高度-子窗体高度)/2
		//设置子窗体位置，高度-70，70包含标题、菜单栏和工具栏的高度
		jif.setLocation(x, y-70);
    }
}