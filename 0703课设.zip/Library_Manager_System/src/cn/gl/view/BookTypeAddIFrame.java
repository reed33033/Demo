package cn.gl.view;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JPanel;

import java.awt.Font;
import javax.swing.JTextField;

import cn.gl.factory.ServiceFactory;
import cn.gl.vo.BookType;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 图书类别添加界面
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class BookTypeAddIFrame extends JInternalFrame {
	private JTextField typeidtxt;
	private JTextField typenametxt;
	int id = 100000000;

	/**
	 * Launch the application.
	 */
	private static BookTypeAddIFrame btaddfm = null;// 定义子窗体为私有
	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized BookTypeAddIFrame GetInstance() {
		if (btaddfm == null) {
			btaddfm = new BookTypeAddIFrame();
		}
		return btaddfm;
	}

	/**
	 * Create the frame.
	 */
	public BookTypeAddIFrame() {
		setTitle("图书类别添加");
		setClosable(true);
		setBounds(100, 100, 465, 452);
		getContentPane().setLayout(new BorderLayout(0, 0));

		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);

		final JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(BookTypeAddIFrame.class.getResource("/source/bookTypeAdd.jpg")));
		lblNewLabel.setBounds(3, 2, 430, 87);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(3, 88, 446, 323);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("图书类别编号：");
		lblNewLabel_1.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(133, 15, 154, 36);
		panel_1.add(lblNewLabel_1);

		typeidtxt = new JTextField();
		typeidtxt.setFont(new Font("宋体", Font.PLAIN, 22));
		typeidtxt.setBounds(33, 66, 358, 36);
		panel_1.add(typeidtxt);
		typeidtxt.setColumns(10);
		typeidtxt.setEditable(false);
		try {
			id = ServiceFactory.getIBookTypeServiceInstance().findLastId().getTypeId();
			typeidtxt.setText(String.valueOf(id + 1));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		JLabel lblNewLabel_1_1 = new JLabel("图书类别名称：");
		lblNewLabel_1_1.setFont(new Font("宋体", Font.PLAIN, 22));
		lblNewLabel_1_1.setBounds(133, 129, 154, 36);
		panel_1.add(lblNewLabel_1_1);

		typenametxt = new JTextField();
		typenametxt.setFont(new Font("宋体", Font.PLAIN, 22));
		typenametxt.setColumns(10);
		typenametxt.setBounds(33, 170, 358, 36);
		panel_1.add(typenametxt);

		JButton btnNewButton = new JButton("添加");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Boolean flag = false;
				try {

					BookType booktype = new BookType(id + 1, typenametxt.getText().toString().trim());
					flag = ServiceFactory.getIBookTypeServiceInstance().insert(booktype);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (flag) {
					JOptionPane.showMessageDialog(null, "添加成功！");
					try {
						id = ServiceFactory.getIBookTypeServiceInstance().findLastId().getTypeId();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					typeidtxt.setText(String.valueOf(id + 1));
					return;
				} else {
					JOptionPane.showMessageDialog(null, "添加失败，该类别已存在！");
					return;
				}
			}
		});
		btnNewButton.setFont(new Font("宋体", Font.PLAIN, 23));
		btnNewButton.setBounds(33, 242, 140, 43);
		panel_1.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("取消");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				typeidtxt.setText("");
				typenametxt.setText("");
				doDefaultCloseAction();
			}
		});
		btnNewButton_1.setFont(new Font("宋体", Font.PLAIN, 23));
		btnNewButton_1.setBounds(251, 242, 140, 43);
		panel_1.add(btnNewButton_1);

	}
}
