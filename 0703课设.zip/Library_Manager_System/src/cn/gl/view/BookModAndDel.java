package cn.gl.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.Vector;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import com.eltima.components.ui.DatePicker;

import cn.gl.factory.ServiceFactory;
import cn.gl.view.BookFindIFrame.MyTable;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;
import cn.gl.vo.Reader;

import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * 本类为图书修改和查询界面
 * 
 * @author 高丽
 * @version V1.0
 */
public class BookModAndDel extends JInternalFrame {

	/**
	 * Launch the application.
	 */

	private static BookModAndDel bookmdfm = null;// 定义子窗体为私有
	private JTextField choicetxt;
	private JComboBox choice;
	private String bookfind[] = { "编号", "分类", "名称", "作者", "出版社", "出版日期", "单价", "数量" };
	private JTable table;
	private JTextField ISBNtxt;
	private JTextField booknametxt;
	private JTextField authortxt;
	private JTextField publishtxt;
	private JTextField pricetxt;
	private JTextField numbertxt;
	private int currentPage = 1;
	private int pageSize = 8;
	private int lastPage;
	private List<Book> list = new ArrayList<Book>();
	DefaultTableModel model = new DefaultTableModel();
	JScrollPane scrollPane;
	JButton findbtn;
	DefaultComboBoxModel bookTypeModel;
	SimpleDateFormat myfmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Date date = new java.util.Date();
	JComboBox booktype;
	JLabel lblNewLabel;

	// 静态公开方法，只产生一个对象，synchronized保证线程案例

	public static synchronized BookModAndDel GetInstance() {
		if (bookmdfm == null) {
			bookmdfm = new BookModAndDel();
		}
		return bookmdfm;
	}

	private static DatePicker getDatePicker() {
		final DatePicker datepick;
		// 格式
		String DefaultFormat = "yyyy-MM-dd HH:mm:ss";
		// 当前时间
		Date date = new Date();
		// 字体
		Font font = new Font("Times New Roman", Font.BOLD, 14);

		Dimension dimension = new Dimension(177, 24);

		int[] hilightDays = { 1, 3, 5, 7 };

		// int[] disabledDays = { 4, 6, 5, 9 };

		datepick = new DatePicker(date, DefaultFormat, font, dimension);

		datepick.setLocation(137, 83);
		datepick.setBounds(137, 83, 177, 24);
		// 设置一个月份中需要高亮显示的日子
		datepick.setHightlightdays(hilightDays, Color.red);
		// 设置一个月份中不需要的日子，呈灰色显示
		// datepick.setDisableddays(disabledDays);
		// 设置国家
		datepick.setLocale(Locale.CHINA);
		// 设置时钟面板可见
		datepick.setTimePanleVisible(true);
		return datepick;
	}

	private Object[][] getselect(List list) {
		Object[][] s = new Object[list.size()][8];
		for (int i = 0; i < list.size(); i++) {
			Book book = (Book) list.get(i);
			s[i][0] = book.getISBN();
			String booktypename = null;
			try {
				booktypename = ServiceFactory.getIBookTypeServiceInstance().get(book.getTypeId()).getTypeName();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			s[i][1] = booktypename;
			s[i][2] = book.getBookName();
			s[i][3] = book.getAuthor();
			s[i][4] = book.getPublish();
			s[i][5] = book.getPublishDate();
			s[i][6] = book.getUnitPrice();
			s[i][7] = book.getAmount();
		}
		return s;

	}

	private Object[] getselectid(List list) {
		Object[] ids = new Object[list.size()];
		for (int i = 0; i < list.size(); i++) {
			Book book = null;
			book = (Book) list.get(i);
			ids[i] = book.getISBN();
		}
		return ids;
	}

	public void showTable(List list, int currentPage) {
		model.setRowCount(0);// 清除原有行
		setCurrentPage(currentPage);
		List<Book> list1 = null;
		list1 = findBook(list, currentPage, pageSize);
		for (int row = 0; row < list1.size(); row++) // 获得数据
		{
			Vector rowV = new Vector();
			Book book = (Book) list1.get(row);
			rowV.add(book.getISBN()); // 数据
			BookType type = null;
			try {
				type = ServiceFactory.getIBookTypeServiceInstance().get(book.getTypeId());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			rowV.add(type.getTypeName());
			rowV.add(book.getBookName());
			rowV.add(book.getAuthor());
			rowV.add(book.getPublish());
			rowV.add((book.getPublishDate()));
			rowV.add((book.getUnitPrice()));
			rowV.add((book.getAmount()));
			model.addRow(rowV);
		}

		// table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); //关闭表格列的自动调整功能。
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // 单选
		table.setSelectionBackground(Color.YELLOW);
		table.setSelectionForeground(Color.RED);
		table.setRowHeight(30);
	}

	public static List<Book> findBook(List list, int currentPage, int pageSize) {

		List<Book> list1 = new ArrayList();
		int listLength = list.size();
		if (currentPage < 1) {
			currentPage = 1;
		}
		int startIndex = (currentPage - 1) * pageSize;
		int endIndex = startIndex + pageSize;

		if (endIndex >= listLength) {
			endIndex = listLength;
		}
		list1 = list.subList(startIndex, endIndex);
		return list1;
	}

	public int getLastPage() {
		return lastPage;
	}

	public void setLastPage(int lastPage) {
		this.lastPage = lastPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	/**
	 * Create the frame.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public BookModAndDel() {
		setTitle("图书信息修改与删除");
		setResizable(true);
		setClosable(true);
		setBounds(100, 100, 658, 691);
		getContentPane().setLayout(null);

		JPanel panel1 = new JPanel();
		panel1.setBounds(0, 0, 642, 650);
		getContentPane().add(panel1);
		panel1.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 15, 623, 69);
		panel.setBorder(new TitledBorder(null, "\u8BF7\u9009\u62E9\u67E5\u8BE2\u6761\u4EF6", TitledBorder.LEADING,
				TitledBorder.TOP, null, null));
		panel1.add(panel);

		choice = new JComboBox();
		choice.setFont(new Font("宋体", Font.PLAIN, 22));
		panel.add(choice);
		String[] array = { "图书名称", "图书编号" };
		for (int i = 0; i < array.length; i++) {
			choice.addItem(array[i]);

		}

		choicetxt = new JTextField();
		choicetxt.setFont(new Font("宋体", Font.PLAIN, 22));
		panel.add(choicetxt);
		choicetxt.setColumns(23);

		findbtn = new JButton("查询");
		findbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String choose = choice.getSelectedItem().toString().trim();
				if (choose.equals("图书编号")) {
					// List<Book> list=new ArrayList<Book>();
					Object[][] results = null;
					Book book = null;
					try {
						book = ServiceFactory.getIBookServiceInstance().get(choicetxt.getText().toString().trim());
						list.add(book);
					} catch (Exception e1) {
						JOptionPane.showMessageDialog(null, "图书编号不存在！");
						return;
					}
					if (book == null) {
						JOptionPane.showMessageDialog(null, "图书编号不存在！");
						return;
					} else {
						if (list.size() % pageSize == 0) {
							setLastPage(list.size() / getPageSize());
						} else {
							setLastPage(list.size() / getPageSize() + 1);
						}

						// results = getselect(list);
						// DefaultTableModel model=new DefaultTableModel();
						// table.setModel(model);
						// model.setDataVector(results, bookfind);
						model = new DefaultTableModel(bookfind, 0);

						// table=new JTable(model);
						table = new JTable(model);
						RowSorter sorter = new TableRowSorter(model);
						table.setRowSorter(sorter);
						table.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseClicked(final MouseEvent e) {
								int selRow = table.getSelectedRow();
								ISBNtxt.setText(table.getValueAt(selRow, 0).toString().trim());
								booknametxt.setText(table.getValueAt(selRow, 2).toString().trim());
								authortxt.setText(table.getValueAt(selRow, 3).toString().trim());
								publishtxt.setText(table.getValueAt(selRow, 4).toString().trim());
								pricetxt.setText(table.getValueAt(selRow, 6).toString().trim());
								numbertxt.setText(table.getValueAt(selRow, 7).toString().trim());
							}
						});
						pageSize = 8;
						currentPage = 1;

						showTable(list, currentPage);
					}
				} else if (choose.equals("图书名称")) {
					// List<Book> list=new ArrayList<Book>();
					Object[][] results = null;
					list = null;
					try {
						list = ServiceFactory.getIBookServiceInstance().findbook(choicetxt.getText().toString().trim());

					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if (list.size() == 0) {
						JOptionPane.showMessageDialog(null, "书籍不存在！");
						return;
					} else {
						if (list.size() % pageSize == 0) {
							setLastPage(list.size() / getPageSize());
						} else {
							setLastPage(list.size() / getPageSize() + 1);
						}
						// results = getselect(list);
						// DefaultTableModel model=new DefaultTableModel();
						// table.setModel(model);
						// model.setDataVector(results, bookfind);
						model = new DefaultTableModel(bookfind, 0);
						table = new JTable(model);
						RowSorter sorter = new TableRowSorter(model);
						table.setRowSorter(sorter);
						table.addMouseListener(new MouseAdapter() {
							@Override
							public void mouseClicked(final MouseEvent e) {
								int selRow = table.getSelectedRow();
								ISBNtxt.setText(table.getValueAt(selRow, 0).toString().trim());
								booknametxt.setText(table.getValueAt(selRow, 2).toString().trim());
								authortxt.setText(table.getValueAt(selRow, 3).toString().trim());
								publishtxt.setText(table.getValueAt(selRow, 4).toString().trim());
								pricetxt.setText(table.getValueAt(selRow, 6).toString().trim());
								numbertxt.setText(table.getValueAt(selRow, 7).toString().trim());
							}
						});
						scrollPane.setViewportView(table);
						pageSize = 8;
						currentPage = 1;
						showTable(list, currentPage);
					}
				}

			}
		});
		findbtn.setFont(new Font("宋体", Font.PLAIN, 23));
		panel.add(findbtn);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 87, 623, 284);
		panel1.add(panel_1);
		panel_1.setLayout(null);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 623, 284);
		panel_1.add(scrollPane);

		// List<Book> list1=new ArrayList<Book>();
//				try {
//					list1=ServiceFactory.getIBookServiceInstance().getAll();
//				} catch (Exception e2) {
//					// TODO Auto-generated catch block
//					e2.printStackTrace();
//				}
//				Object[][] results=getselect(list1);

		try {
			list = ServiceFactory.getIBookServiceInstance().getAll();
			if (list.size() % pageSize == 0) {
				setLastPage(list.size() / getPageSize());
			} else {
				setLastPage(list.size() / getPageSize() + 1);
			}

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		model = new DefaultTableModel(bookfind, 0);

		table = new JTable(model);
		RowSorter sorter = new TableRowSorter(model);
		table.setRowSorter(sorter);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(final MouseEvent e) {
				int selRow = table.getSelectedRow();
				ISBNtxt.setText(table.getValueAt(selRow, 0).toString().trim());
				booknametxt.setText(table.getValueAt(selRow, 2).toString().trim());
				authortxt.setText(table.getValueAt(selRow, 3).toString().trim());
				publishtxt.setText(table.getValueAt(selRow, 4).toString().trim());
				pricetxt.setText(table.getValueAt(selRow, 6).toString().trim());
				numbertxt.setText(table.getValueAt(selRow, 7).toString().trim());
			}
		});
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		scrollPane.setViewportView(table);
		showTable(list, currentPage);

		JPanel panel_4 = new JPanel();
		panel1.add(panel_4);
		final GridLayout gridLayout = new GridLayout(0, 4);
		gridLayout.setVgap(15);
		gridLayout.setHgap(10);
		panel_4.setLayout(gridLayout);
		panel_4.setBounds(0, 435, 623, 155);

		JLabel Label = new JLabel("图书编号：");
		Label.setBounds(27, 8, 90, 21);
		panel_4.add(Label);

		ISBNtxt = new JTextField();
		ISBNtxt.setBounds(112, 5, 141, 27);
		panel_4.add(ISBNtxt);
		ISBNtxt.setColumns(15);
		ISBNtxt.setEditable(false);

		JLabel lblNewLabel_1 = new JLabel("图书类型：");
		lblNewLabel_1.setBounds(298, 8, 95, 21);
		panel_4.add(lblNewLabel_1);

		booktype = new JComboBox();
		booktype.setBounds(408, 5, 41, 27);
		booktype.setMaximumRowCount(12);
		bookTypeModel = (DefaultComboBoxModel) booktype.getModel();
		panel_4.add(booktype);
		// 从数据库中取出图书类别
		List<BookType> list2 = new ArrayList<BookType>();
		try {
			list2 = ServiceFactory.getIBookTypeServiceInstance().list();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for (int i = 0; i < list2.size(); i++) {
			BookType bktype = (BookType) list2.get(i);
			toStringtype type = new toStringtype();
			type.setTypeid(bktype.getTypeId().toString());
			type.setTypename(bktype.getTypeName());
			bookTypeModel.addElement(type);
		}

		JLabel ISBNtxt_1 = new JLabel("图书名称：");
		ISBNtxt_1.setBounds(27, 44, 90, 21);
		panel_4.add(ISBNtxt_1);

		booknametxt = new JTextField();
		booknametxt.setColumns(15);
		booknametxt.setBounds(112, 41, 141, 27);
		panel_4.add(booknametxt);
		booknametxt.setEditable(false);

		JLabel ISBNtxt_1_1 = new JLabel("作者：");
		ISBNtxt_1_1.setBounds(298, 44, 90, 21);
		panel_4.add(ISBNtxt_1_1);

		authortxt = new JTextField();
		authortxt.setColumns(15);
		authortxt.setBounds(408, 47, 141, 27);
		panel_4.add(authortxt);
		authortxt.setEditable(false);

		JLabel ISBNtxt_1_2 = new JLabel("出版社：");
		ISBNtxt_1_2.setBounds(27, 80, 90, 21);
		panel_4.add(ISBNtxt_1_2);

		publishtxt = new JTextField();
		publishtxt.setColumns(15);
		publishtxt.setBounds(112, 77, 141, 27);
		panel_4.add(publishtxt);
		publishtxt.setEditable(false);

		final DatePicker datepick;
		datepick = getDatePicker();
		JLabel ISBNtxt_1_2_1 = new JLabel("出版日期：");
		ISBNtxt_1_2_1.setBounds(298, 80, 90, 21);
		panel_4.add(ISBNtxt_1_2_1);
		panel_4.add(datepick);

		JLabel ISBNtxt_1_2_2 = new JLabel("单价：");
		ISBNtxt_1_2_2.setBounds(27, 116, 90, 21);
		panel_4.add(ISBNtxt_1_2_2);

		pricetxt = new JTextField();
		pricetxt.setColumns(15);
		pricetxt.setBounds(112, 113, 141, 27);
		panel_4.add(pricetxt);

		JLabel ISBNtxt_1_2_2_1 = new JLabel("数量：");
		ISBNtxt_1_2_2_1.setBounds(298, 116, 90, 21);
		panel_4.add(ISBNtxt_1_2_2_1);

		numbertxt = new JTextField();
		numbertxt.setColumns(15);
		numbertxt.setBounds(408, 113, 141, 27);
		panel_4.add(numbertxt);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(64, 605, 499, 45);
		panel1.add(panel_2);

		JButton btnNewButton_2_5 = new JButton("删除");
		panel_2.add(btnNewButton_2_5);
		btnNewButton_2_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int selectedRow = table.getSelectedRow();
				String id = ISBNtxt.getText().toString().trim();
				Boolean flag = false;
				Set<String> all = new HashSet<String>();
				// List<Book> list=new ArrayList<Book>();
				all.add(id);
				try {
					flag = ServiceFactory.getIBookServiceInstance().delete(all);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Object[][] results = null;
				if (flag) {
					model.removeRow(selectedRow);
					JOptionPane.showMessageDialog(null, "删除成功！");

				} else {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "删除失败");
				}
			}
		});
		btnNewButton_2_5.setFont(new Font("宋体", Font.PLAIN, 22));

		JButton btnNewButton_2_5_1 = new JButton("修改");
		panel_2.add(btnNewButton_2_5_1);
		btnNewButton_2_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (pricetxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "单价文本框不可为空");
					return;
				}
				if (numbertxt.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "数量文本框不可为空");
					return;
				}
				Book book = null;
				List<BookType> type = new ArrayList<BookType>();
				try {
					book = ServiceFactory.getIBookServiceInstance().get(ISBNtxt.getText().toString().trim());
					type = ServiceFactory.getIBookTypeServiceInstance()
							.get(booktype.getSelectedItem().toString().trim());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				book.setTypeId(type.get(0).getTypeId());
				book.setUnitPrice(Double.parseDouble(pricetxt.getText().toString().trim()));
				book.setAmount(Integer.valueOf(numbertxt.getText().toString().trim()));
				Boolean flag = false;
				try {
					flag = ServiceFactory.getIBookServiceInstance().update(book);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Object[][] results = null;
				if (flag) {
					int selectedRow = table.getSelectedRow();
					Object val = type.get(0).getTypeName();
					model.setValueAt(val, selectedRow, 1);
					val = pricetxt.getText().toString().trim();
					model.setValueAt(val, selectedRow, 6);
					val = numbertxt.getText().toString().trim();
					model.setValueAt(val, selectedRow, 7);
					JOptionPane.showMessageDialog(null, "修改成功！");

					return;
				} else {
					JOptionPane.showMessageDialog(null, "修改失败！");
					return;
				}
			}
		});
		btnNewButton_2_5_1.setFont(new Font("宋体", Font.PLAIN, 22));

		JButton btnNewButton_2 = new JButton("退出");
		panel_2.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doDefaultCloseAction();
			}
		});
		btnNewButton_2.setFont(new Font("宋体", Font.PLAIN, 22));

		JButton btnNewButton_2_5_3 = new JButton("清空图书");
		btnNewButton_2_5_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Boolean flag = false;
				flag = ServiceFactory.getIBookServiceInstance().deleteAll();
				if (flag) {
					model.setRowCount(0);// 清除原有行
					JOptionPane.showMessageDialog(null, "清空成功！");
					return;
				} else {
					JOptionPane.showMessageDialog(null, "清空失败！");
					return;
				}

			}
		});
		btnNewButton_2_5_3.setFont(new Font("宋体", Font.PLAIN, 22));
		panel_2.add(btnNewButton_2_5_3);

		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBounds(15, 387, 568, 45);
		panel1.add(panel_2_1);

		lblNewLabel = new JLabel("");
		panel_2_1.add(lblNewLabel);

		JButton btnNewButton_2_5_2 = new JButton("首页");
		btnNewButton_2_5_2.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_5_2.addActionListener(new MyTable());
		panel_2_1.add(btnNewButton_2_5_2);

		JButton btnNewButton_2_5_1_1 = new JButton("上一页");
		btnNewButton_2_5_1_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_5_1_1.addActionListener(new MyTable());
		panel_2_1.add(btnNewButton_2_5_1_1);

		JButton btnNewButton_2_1 = new JButton("下一页");
		btnNewButton_2_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_1.addActionListener(new MyTable());
		panel_2_1.add(btnNewButton_2_1);

		JButton btnNewButton_2_5_2_1 = new JButton("尾页");
		btnNewButton_2_5_2_1.setFont(new Font("宋体", Font.PLAIN, 22));
		btnNewButton_2_5_2_1.addActionListener(new MyTable());
		panel_2_1.add(btnNewButton_2_5_2_1);

	}

	class MyTable implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			// List list=null;
			try {
				// list = ServiceFactory.getIBookServiceInstance().getAll();
				int page = list.size() / getPageSize() + 1;
				lblNewLabel.setText("总共" + page + "页|当前第" + 1 + "页");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (e.getActionCommand().equals("首页")) {
				showTable(list, 1);
			}

			if (e.getActionCommand().equals("上一页")) {
				int page = getCurrentPage() + 1;
				int page1 = list.size() / getPageSize() + 1;
				lblNewLabel.setText("总共" + page1 + "页|当前第" + page + "页");
				if (getCurrentPage() <= 1) {
					setCurrentPage(2);

				}
				showTable(list, getCurrentPage() - 1);
			}

			if (e.getActionCommand().equals("下一页")) {
				int page1 = list.size() / getPageSize() + 1;
				int page = getCurrentPage() + 1;
				lblNewLabel.setText("总共" + page1 + "页|当前第" + page + "页");
				if (getCurrentPage() < getLastPage()) {
					showTable(list, getCurrentPage() + 1);
				} else {
					lblNewLabel.setText("总共" + page1 + "页|当前第" + getLastPage() + "页");
					showTable(list, getLastPage());
				}
			}

			if (e.getActionCommand().equals("尾页")) {
				int page1 = list.size() / getPageSize() + 1;
				lblNewLabel.setText("总共" + page1 + "页|当前第" + getLastPage() + "页");
				showTable(list, getLastPage());

			}
		}
	}
}
