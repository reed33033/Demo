package cn.gl.dao;

import java.util.List;

/**
 *  此类为图书类别表的数据层操作标准
 */
import cn.gl.vo.BookType;

/**
 * 本类为图书类别表的数据层操作标准
 * 
 * @author 高丽
 * @version V1.0
 */
public interface IBookTypeDAO extends IDAO<Integer, BookType> {
	/**
	 * 取得数据表的最后一个数据
	 * 
	 * @return 数据表的最后一个数据，如果不存在则返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public BookType findLast() throws Exception;

	/**
	 * 根据图书类别的名称取得图书类别信息
	 * 
	 * @param typename 图书类别名称
	 * @return 查询到的所有图书类别信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<BookType> findByName(String typename) throws Exception;
}
