package cn.gl.dao;

import java.util.List;

/**
 *  此类为图书表的数据层操作标准
 */
import cn.gl.vo.Book;

/**
 * 本类为图书表的数据层操作标准
 * 
 * @author 高丽
 * @version V1.0
 */
public interface IBookDAO extends IDAO<String, Book> {
	/**
	 * 根据书籍的名称bookname取得书籍的信息
	 * 
	 * @param bookname 书籍的名称
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<Book> findByName(String bookname) throws Exception;

	/**
	 * 取得数据表的最后一个数据
	 * 
	 * @return 数据表的最后一个数据
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public Book findLast() throws Exception;

	/**
	 * 分页进行数据表的模糊查询操作，每行数据通过Book类包装，而后通过List保存多个返回结果
	 * 
	 * @param columun      要模糊查询的数据列
	 * @param keyWord     要进行查询的关键字
	 * @param currentPage 当前所在页
	 * @param lineSize    每页显示的数据行数
	 * @return      全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<Book> findAllSplit(String columun, String keyWord, Integer currentPage, Integer lineSize)
			throws Exception;

	/**
	 * 使用COUNT()函数统计数据表中符合查询要求的数据量
	 * 
	 * @param columun  要模糊查询的数据列
	 * @param keyWord 要进行查询的关键字
	 * @return  返回COUNT()的统计结果，如果没有数据满足，则返回内容为0
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public Integer getAllCount(String columun, String keyWord) throws Exception;

	/**
	 * 清空图书表内的所有数据，即删除所有数据
	 * 
	 * @return 如果删除成功则返回true，失败返回false
	 */
	public Boolean doRemoveAll();
}
