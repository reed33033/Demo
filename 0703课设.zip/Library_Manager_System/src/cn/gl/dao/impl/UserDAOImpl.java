package cn.gl.dao.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import cn.gl.dao.IUserDAO;
import cn.gl.vo.User;

/**
 * 此类为IUserDao的实现类
 * 
 * @author 高丽
 * @version V1.0
 *
 */
/*
 * 要想操作数据层子类，那么一定要在构造方法中传入Connection接口对象
 */
public class UserDAOImpl implements IUserDAO {
	// 为了保证文件一加载就创建
	private static File file = new File("user.txt");
	private static List<User> users = new ArrayList<>();// 存储用户的列表集合
	private static int n;// 存储用户数

	public UserDAOImpl() {
	}

	static {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
			String line = null;
			User user = null;
			while ((line = br.readLine()) != null) {
				// 用户名,密码
				String[] datas = line.split(",");
				user = new User(datas[0], datas[1]);
				users.add(user);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					System.out.println("用户登录释放资源失败");
					// e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 将list的内容存入文件中
	 * 
	 * @param list 包含用户名和密码的集合
	 * @return 如果存入成功返回true，失败返回false
	 */
	public boolean writeIn(List list) {
		FileWriter fileWriter;
		try {
			fileWriter = new FileWriter(file);

			fileWriter.write("");
			fileWriter.flush();
			fileWriter.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		Iterator<User> iterable = users.iterator();
		while (iterable.hasNext()) {
			User user = iterable.next();
			BufferedWriter bw = null;
			try {

				bw = new BufferedWriter(new FileWriter(file, true));
				bw.write(user.getUserName() + "," + user.getPassword());
				bw.newLine();
				bw.flush();
			} catch (IOException e) {
				// System.out.println("用户添加失败");
				return false;
			} finally {
				if (bw != null) {
					try {
						bw.close();
					} catch (IOException e) {
						System.out.println("用户添加注册释放资源失败");
						// e.printStackTrace();
						return false;
					}
				}
			}
		}
		return true;
	}

	/**
	 * 根据用户名取得用户信息
	 * 
	 * @param username 用户名
	 * @return 如果查询到则将内容以User对象的形式返回，如果查到没有数据返回null
	 */
	@Override
	public User findById(String username) throws Exception {
		User user = null;
		for (int i = 0; i < users.size(); i++) {
			user = users.get(i);
			if (user.getUserName().equals(username)) {
				return user;
			}
		}
		return null;
	}

	/**
	 * 添加用户
	 * 
	 * @param user 欲添加的用户
	 * @return 如果数据增加成功 返回true 否则返回false
	 */
	@Override
	public boolean doCreate(User user) throws Exception {
		/*
		 * 为了让注册的数据能够有一定的规则，我就自己定义了一个规则： 用户名,密码
		 */
		BufferedWriter bw = null;
		try {
			// 为了保证数据是追加写入，必须加true
			bw = new BufferedWriter(new FileWriter(file, true));
			bw.write(user.getUserName() + "," + user.getPassword());
			bw.newLine();
			bw.flush();
			users.add(user);
			return true;
		} catch (IOException e) {
			System.out.println("用户添加失败");
			return false;
			// e.printStackTrace();
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					System.out.println("用户添加注册释放资源失败");
					// e.printStackTrace();
					return false;
				}
			}
		}
	}

	/**
	 * 更新用户信息
	 * 
	 * @param user 欲更新的用户信息
	 * @return 如果数据修改成功 返回true 否则返回false
	 */
	@Override
	public boolean doUpdate(User user) throws Exception {
		User user1 = null;
		int i = 0;
		boolean flag = false;
		for (i = 0; i < users.size(); i++) {
			user1 = users.get(i);
			if (user1.getUserName().equals(user.getUserName())) {
				flag = true;
				break;
			}
		}
		if (flag) {
			users.set(i, user);
			return writeIn(users);
		} else {
			return false;
		}
	}

	/**
	 * 删除用户
	 * 
	 * @param username 所有要删除的用户名
	 * @return 如果数据删除成功 返回true 否则返回false
	 */
	@Override
	public boolean doRemove(String username) throws Exception {
		for (int i = 0; i < users.size(); i++) {
			User s = users.get(i);
			if (s.getUserName().equals(username)) {
				users.remove(i);
				break;
			}
		}

		return writeIn(users);
	}

	/**
	 * 根据用户名和密码取得用户信息
	 * 
	 * @param userName 用户的姓名
	 * @param password 用户密码
	 * @return 如果查询到则将内容以User对象的形式返回，如果查到没有数据返回null
	 */
	@Override
	public User findByName(String userName, String password) throws Exception {
		User user = null;
		for (int i = 0; i < users.size(); i++) {
			user = users.get(i);
			if (user.getUserName().equals(userName) && user.getPassword().equals(password)) {
				return user;
			}
		}
		return null;
	}

	/**
	 * 取得所有用户信息
	 * 
	 * @return 所有用户信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 */
	@Override
	public List<User> findAll() throws Exception {
		return users;
	}

	/**
	 * 按字段排序取得所有用户信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有用户信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 */
	@Override
	public List<User> OrderAll(String name, String choose) throws Exception {
		if (name.contentEquals("userName")) {
			if (choose.equals("desc")) {
				Collections.sort(users, new Comparator<User>() {
					@Override
					public int compare(User o1, User o2) {
						// 降序
						return o2.getUserName().compareTo(o1.getUserName());
					}
				});
			} else {
				Collections.sort(users, new Comparator<User>() {
					@Override
					public int compare(User o1, User o2) {
						// 升序
						return o1.getUserName().compareTo(o2.getUserName());
					}
				});
				writeIn(users);
				return users;
			}
		} else {
			if (choose.equals("desc")) {
				Collections.sort(users, new Comparator<User>() {
					@Override
					public int compare(User o1, User o2) {
						// 降序
						return o2.getPassword().compareTo(o1.getPassword());
					}
				});
			} else {
				Collections.sort(users, new Comparator<User>() {
					@Override
					public int compare(User o1, User o2) {
						// 升序
						return o1.getPassword().compareTo(o2.getPassword());
					}
				});
			}
			writeIn(users);
			return users;
		}
		return users;
	}
}
