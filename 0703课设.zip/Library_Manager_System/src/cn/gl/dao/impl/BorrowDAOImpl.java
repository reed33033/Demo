package cn.gl.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import cn.gl.dao.IBorrowDAO;
import cn.gl.vo.BookType;
import cn.gl.vo.Borrow;
import cn.gl.vo.User;

/**
 * 此类为IBorrowDao的实现类
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class BorrowDAOImpl implements IBorrowDAO {
	/*
	 * 要想操作数据层子类，那么一定要在构造方法中传入Connection接口对象
	 */
	private Connection conn; // 数据库连接对象

	private PreparedStatement pstmt;// 数据库操作对象
	/*
	 * 实例化数据层子类对象，同时传入一个数据库连接对象 conn Connection连接对象，如果为null表示数据库没有打开
	 */

	public BorrowDAOImpl(Connection conn) {
		this.conn = conn;
	}

	/**
	 * 添加借书记录用户
	 * 
	 * @param borrow 欲添加的借书记录
	 * @return 如果数据增加成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doCreate(Borrow borrow) throws Exception {
		String sql = "INSERT INTO tb_borrow(ISBN,userName,readerId,borrowDate,returnDate,fine) VALUES(?,?,?,?,?,?)";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, borrow.getISBN());
		this.pstmt.setString(2, borrow.getUserName());
		this.pstmt.setInt(3, borrow.getReaderId());
		this.pstmt.setDate(4, new java.sql.Date(borrow.getBorrowDate().getTime()));
		this.pstmt.setDate(5, new java.sql.Date(borrow.getReturnDate().getTime()));
		this.pstmt.setDouble(6, borrow.getFine());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 更新借书信息
	 * 
	 * @param borrow 欲更新的借书户信息
	 * @return 如果数据修改成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doUpdate(Borrow borrow) throws Exception {
		String sql = "UPDATE tb_borrow SET borrowId=?,ISBN=?,userName=?,readerId=?,borrowDate=?,returnDate=?,fine=? WHERE borrowId=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, borrow.getBorrowId());
		this.pstmt.setString(2, borrow.getISBN());
		this.pstmt.setString(3, borrow.getUserName());
		this.pstmt.setInt(4, borrow.getReaderId());
		this.pstmt.setDate(5, new java.sql.Date(borrow.getBorrowDate().getTime()));
		this.pstmt.setDate(6, new java.sql.Date(borrow.getReturnDate().getTime()));
		this.pstmt.setDouble(7, borrow.getFine());
		this.pstmt.setInt(8, borrow.getBorrowId());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 删除借书记录
	 * 
	 * @param ids 所有要删除的借书记录编号
	 * @return 如果数据删除成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doRemove(Set<Integer> ids) throws Exception {
		StringBuffer buf = new StringBuffer();
		buf.append("DELETE FROM tb_borrow WHERE borrowId IN(");
		Iterator<Integer> iter = ids.iterator();
		while (iter.hasNext()) {
			buf.append(iter.next()).append(",");
		}
		buf.delete(buf.length() - 1, buf.length()).append(")");
		this.pstmt = this.conn.prepareStatement(buf.toString());
		return this.pstmt.executeUpdate() == ids.size();
	}

	/**
	 * 根据借书的编号记录id取得借书记录信息
	 * 
	 * @param id 借书编号
	 * @return 如果查询到则将内容以Borrow对象的形式返回，如果查到没有数据返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public Borrow findById(Integer id) throws Exception {
		Borrow borrow = null;
		String sql = "SELECT * FROM tb_borrow WHERE borrowId =?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, id);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			borrow = new Borrow();
			// borrow.setBorrowId(rs.getString(1));
			borrow.setISBN(rs.getString(2));
			borrow.setUserName(rs.getString(3));
			borrow.setReaderId(rs.getInt(4));
			borrow.setBorrowDate(rs.getDate(5));
			borrow.setReturnDate(rs.getDate(6));
			borrow.setFine(rs.getDouble(7));
		}
		return borrow;
	}

	/**
	 * 根据读者借书的编号id取得未还书记录信息
	 * 
	 * @param id 读者编号借书编号
	 * @return 查询到的读者所有未还书书记录的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Borrow> findByReaderId(Integer id) throws Exception {
		List<Borrow> list = new ArrayList<Borrow>();
		String sql = "select * from tb_borrow where (select datediff(returnDate,borrowDate)=0) AND readerId=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, id);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			Borrow borrow = new Borrow();
			borrow.setBorrowId(rs.getInt(1));
			borrow.setISBN(rs.getString(2));
			borrow.setUserName(rs.getString(3));
			borrow.setReaderId(rs.getInt(4));
			borrow.setBorrowDate(rs.getDate(5));
			borrow.setReturnDate(rs.getDate(6));
			borrow.setFine(rs.getDouble(7));
			list.add(borrow);
		}

		return list;
	}

	/**
	 * 根据读者借书的编号和书籍编号取得借书记录信息
	 * 
	 * @param readerId 读者编号
	 * @param ISBN   书籍编号
	 * @return 如果查询到则将内容以Borrow对象的形式返回，如果查到没有数据返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public Borrow findByISBN(Integer readerId, String ISBN) throws Exception {
		Borrow borrow = null;
		String sql = "SELECT * FROM tb_borrow WHERE (select datediff(returnDate,borrowDate)=0) AND readerId=? AND ISBN=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, readerId);
		this.pstmt.setString(2, ISBN);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			borrow = new Borrow();
			borrow.setBorrowId(rs.getInt(1));
			borrow.setISBN(rs.getString(2));
			borrow.setUserName(rs.getString(3));
			borrow.setReaderId(rs.getInt(4));
			borrow.setBorrowDate(rs.getDate(5));
			borrow.setReturnDate(rs.getDate(6));
			borrow.setFine(rs.getDouble(7));
		}
		return borrow;
	}

	/**
	 * 查询数据表中的全部数据，每行数据通过Borrow类包装，而后通过List保存多个返回结果
	 * 
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Borrow> findAll() throws Exception {
		List<Borrow> list = new ArrayList<Borrow>();
		String sql = "SELECT * FROM tb_borrow";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();

		while (rs.next()) {
			Borrow borrow = new Borrow();
			borrow.setBorrowId(rs.getInt(1));
			borrow.setISBN(rs.getString(2));
			borrow.setUserName(rs.getString(3));
			borrow.setReaderId(rs.getInt(4));
			borrow.setBorrowDate(rs.getDate(5));
			borrow.setReturnDate(rs.getDate(6));
			borrow.setFine(rs.getDouble(7));
			list.add(borrow);
		}

		return list;
	}

	/**
	 * 按字段排序取得所有借还书数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Borrow> OrderAll(String name, String choose) throws Exception {
		List<Borrow> list = new ArrayList<Borrow>();

		String sql = "select * from tb_borrow";
		if (choose.equals("desc")) {
			sql = "select * from tb_borrow order by " + name + " desc";
		} else {
			sql = "select * from tb_borrow order by " + name + " asc";
		}
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			Borrow borrow = new Borrow();
			borrow.setBorrowId(rs.getInt(1));
			borrow.setISBN(rs.getString(2));
			borrow.setUserName(rs.getString(3));
			borrow.setReaderId(rs.getInt(4));
			borrow.setBorrowDate(rs.getDate(5));
			borrow.setReturnDate(rs.getDate(6));
			borrow.setFine(rs.getDouble(7));
			list.add(borrow);
		}
		return list;
	}

}
