package cn.gl.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import cn.gl.dao.IBookDAO;
import cn.gl.dao.IReaderDAO;
import cn.gl.vo.BookType;
import cn.gl.vo.Borrow;
import cn.gl.vo.Reader;

/**
 * 此类为IReaderDao的实现类
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class ReaderDAOImpl implements IReaderDAO {
	/*
	 * 要想操作数据层子类，那么一定要在构造方法中传入Connection接口对象
	 */
	private Connection conn;// 数据库连接对象
	private PreparedStatement pstmt;// 数据库操作对象
	/*
	 * 实例化数据层子类对象，同时传入一个数据库连接对象 conn Connection连接对象，如果为null表示数据库没有打开
	 */

	public ReaderDAOImpl(Connection conn) {
		this.conn = conn;
	}

	/**
	 * 读者信息增加的操作，执行的是INSERT语句
	 * 
	 * @param reader 包含了要增加的数据信息
	 * @return 如果数据增加成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doCreate(Reader reader) throws Exception {
		String sql = "INSERT INTO tb_reader VALUES(?,?,?,?,?,?,?,?,?)";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, reader.getReaderId());
		this.pstmt.setString(2, reader.getReaderName());
		this.pstmt.setString(3, reader.getReaderSex());
		this.pstmt.setInt(4, reader.getReaderAge());
		this.pstmt.setString(5, reader.getReaderIdCard());
		this.pstmt.setDate(6, new java.sql.Date(reader.getRegdate().getTime()));
		this.pstmt.setString(7, reader.getReaderPhone());
		this.pstmt.setInt(8, reader.getMaxNum());
		this.pstmt.setDouble(9, reader.getKeepMoney());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 更新读者信息
	 * 
	 * @param reader 欲更新的读者信息
	 * @return 如果数据修改成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doUpdate(Reader reader) throws Exception {
		String sql = "UPDATE tb_reader SET readerId=?,readerName=?,readerSex=?,readerAge=?,readerIdCard=?,regdate=?,readerPhone=?,maxNum=?,keepMoney=? WHERE readerId=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, reader.getReaderId());
		this.pstmt.setString(2, reader.getReaderName());
		this.pstmt.setString(3, reader.getReaderSex());
		this.pstmt.setInt(4, reader.getReaderAge());
		this.pstmt.setString(5, reader.getReaderIdCard());
		this.pstmt.setDate(6, new java.sql.Date(reader.getRegdate().getTime()));
		this.pstmt.setString(7, reader.getReaderPhone());
		this.pstmt.setInt(8, reader.getMaxNum());
		this.pstmt.setDouble(9, reader.getKeepMoney());
		this.pstmt.setInt(10, reader.getReaderId());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 读者信息删除操作，需在执行前根据删除的编号，拼凑出SQL语句
	 * 
	 * @param ids 所有要删除的读者编号数据
	 * @return 如果数据删除成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doRemove(Set<Integer> ids) throws Exception {
		StringBuffer buf = new StringBuffer();
		buf.append("DELETE FROM tb_reader WHERE readerId IN(");
		Iterator<Integer> iter = ids.iterator();
		while (iter.hasNext()) {
			buf.append(iter.next()).append(",");
		}
		buf.delete(buf.length() - 1, buf.length()).append(")");
		this.pstmt = this.conn.prepareStatement(buf.toString());
		return this.pstmt.executeUpdate() == ids.size();
	}

	/**
	 * 根据读者的id取得读者信息
	 * 
	 * @param id 读者编号用户的id
	 * @return 如果查询到则将内容以Reader对象的形式返回，如果查到没有数据返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public Reader findById(Integer id) throws Exception {
		Reader reader = null;
		String sql = "SELECT * FROM tb_reader WHERE readerId = ?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, id);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			reader = new Reader();
			reader.setReaderId(rs.getInt(1));
			reader.setReaderName(rs.getString(2));
			reader.setReaderSex(rs.getString(3));
			reader.setReaderAge(rs.getInt(4));
			reader.setReaderIdCard(rs.getString(5));
			reader.setRegdate(rs.getDate(6));
			reader.setReaderPhone(rs.getString(7));
			reader.setMaxNum(rs.getInt(8));
			reader.setKeepMoney(rs.getDouble(9));
		}
		return reader;
	}

	/**
	 * 查询数据表中的全部数据，每行数据通过Reader类包装，而后通过List保存多个返回结果
	 * 
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Reader> findAll() throws Exception {
		Reader reader = null;
		List<Reader> all = new ArrayList<Reader>();
		String sql = "SELECT * FROM tb_reader";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			reader = new Reader();
			reader.setReaderId(rs.getInt(1));
			reader.setReaderName(rs.getString(2));
			reader.setReaderSex(rs.getString(3));
			reader.setReaderAge(rs.getInt(4));
			reader.setReaderIdCard(rs.getString(5));
			reader.setRegdate(rs.getDate(6));
			reader.setReaderPhone(rs.getString(7));
			reader.setMaxNum(rs.getInt(8));
			reader.setKeepMoney(rs.getDouble(9));
			all.add(reader);
		}
		return all;
	}

	/**
	 * 取得数据表的最后一个数据
	 * 
	 * @return 数据表的最后一个数据，如果不存在则返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public Reader findLast() throws Exception {
		Reader reader = null;
		String sql = "SELECT * FROM tb_reader WHERE readerId = (select max(readerId) from tb_reader)";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			reader = new Reader();
			reader.setReaderId(rs.getInt(1));
			reader.setReaderName(rs.getString(2));
			reader.setReaderSex(rs.getString(3));
			reader.setReaderAge(rs.getInt(4));
			reader.setReaderIdCard(rs.getString(5));
			reader.setRegdate(rs.getDate(6));
			reader.setReaderPhone(rs.getString(7));
			reader.setMaxNum(rs.getInt(8));
			reader.setKeepMoney(rs.getDouble(9));
		}
		return reader;
	}

	/**
	 * 根据读者的姓名取得读者信息
	 * 
	 * @param name 读者姓名
	 * @return 查询到的读者的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Reader> findByName(String name) throws Exception {
		Reader reader = null;
		List<Reader> all = new ArrayList<Reader>();
		String sql = "SELECT * FROM tb_reader where readerName=?";

		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, name);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			reader = new Reader();
			reader.setReaderId(rs.getInt(1));
			reader.setReaderName(rs.getString(2));
			reader.setReaderSex(rs.getString(3));
			reader.setReaderAge(rs.getInt(4));
			reader.setReaderIdCard(rs.getString(5));
			reader.setRegdate(rs.getDate(6));
			reader.setReaderPhone(rs.getString(7));
			reader.setMaxNum(rs.getInt(8));
			reader.setKeepMoney(rs.getDouble(9));
			all.add(reader);
		}
		return all;
	}

	/**
	 * 按字段排序取得所有数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Reader> OrderAll(String name, String choose) throws Exception {
		List<Reader> list = new ArrayList<Reader>();
		Reader reader = null;
		String sql = "select * from tb_reader";
		if (choose.equals("desc")) {
			sql = "select * from tb_reader order by " + name + " desc";
		} else {
			sql = "select * from tb_reader order by " + name + " asc";
		}
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			reader = new Reader();
			reader.setReaderId(rs.getInt(1));
			reader.setReaderName(rs.getString(2));
			reader.setReaderSex(rs.getString(3));
			reader.setReaderAge(rs.getInt(4));
			reader.setReaderIdCard(rs.getString(5));
			reader.setRegdate(rs.getDate(6));
			reader.setReaderPhone(rs.getString(7));
			reader.setMaxNum(rs.getInt(8));
			reader.setKeepMoney(rs.getDouble(9));
			list.add(reader);
		}
		return list;
	}
}
