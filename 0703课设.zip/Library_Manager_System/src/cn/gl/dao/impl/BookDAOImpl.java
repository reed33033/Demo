package cn.gl.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import cn.gl.dao.IBookDAO;
import cn.gl.vo.Book;
import cn.gl.vo.Reader;

/**
 * 此类为IBookDao的实现类
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class BookDAOImpl implements IBookDAO {
	/*
	 * 要想操作数据层子类，那么一定要在构造方法中传入Connection接口对象
	 */
	private Connection conn; //数据库连接对象
	
	private PreparedStatement pstmt;//数据库操作对象
	/*
	 * 实例化数据层子类对象，同时传入一个数据库连接对象 conn Connection连接对象，如果为null表示数据库没有打开
	 */
	public BookDAOImpl(Connection conn) {
		this.conn = conn;
	}

	/**
	 * 更新书籍信息
	 * 
	 * @param book 欲更新的书籍信息
	 * @return 如果数据修改成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,SQLException 如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doUpdate(Book book) throws Exception {
		String sql = "UPDATE tb_book SET ISBN=?,typeId=?,bookName=?,author=?,publish=?,publishDate=?,unitPrice=?,amount=? WHERE ISBN=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, book.getISBN());
		this.pstmt.setInt(2, book.getTypeId());
		this.pstmt.setString(3, book.getBookName());
		this.pstmt.setString(4, book.getAuthor());
		this.pstmt.setString(5, book.getPublish());
		this.pstmt.setDate(6, new java.sql.Date(book.getPublishDate().getTime()));
		this.pstmt.setDouble(7, book.getUnitPrice());
		this.pstmt.setInt(8, book.getAmount());
		this.pstmt.setString(9, book.getISBN());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 根据书籍用户的id编号取得书籍的信息
	 * 
	 * @param id 书籍编号
	 * @return 如果查询到则将内容以Book对象的形式返回，如果查到没有数据返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,SQLException 如果SQL语句错误抛出SQLException
	 */
	@Override
	public Book findById(String id) throws Exception {
		Book book = null;
		String sql = "SELECT * FROM tb_book WHERE ISBN = ?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, id);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			book = new Book();
			book.setISBN(rs.getString(1));
			book.setTypeId(rs.getInt(2));
			book.setBookName(rs.getString(3));
			book.setAuthor(rs.getString(4));
			book.setPublish(rs.getString(5));
			book.setPublishDate(rs.getDate(6));
			book.setUnitPrice(rs.getDouble(7));
			book.setAmount(rs.getInt(8));
		}
		return book;
	}

	/**
	 * 图书数据增加的操作，执行的是INSERT语句
	 * 
	 * @param book 包含了要增加的数据信息
	 * @return 如果数据增加成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,SQLException 如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doCreate(Book book) throws Exception {
		String sql = "INSERT INTO tb_book(ISBN,typeId,bookName,author,publish,publishDate,unitPrice,amount) VALUES(?,?,?,?,?,?,?,?)";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, book.getISBN());
		this.pstmt.setInt(2, book.getTypeId());
		this.pstmt.setString(3, book.getBookName());
		this.pstmt.setString(4, book.getAuthor());
		this.pstmt.setString(5, book.getPublish());
		this.pstmt.setDate(6, new java.sql.Date(book.getPublishDate().getTime()));
		this.pstmt.setDouble(7, book.getUnitPrice());
		this.pstmt.setInt(8, book.getAmount());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 图书数据删除操作，需在执行前根据删除的编号，拼凑出SQL语句
	 * 
	 * @param ids 所有要删除的图书编号数据
	 * @return 如果数据删除成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 * 
	 */
	@Override
	public boolean doRemove(Set<String> ids) throws Exception {
		StringBuffer buf = new StringBuffer();
		buf.append("DELETE FROM tb_book WHERE ISBN IN(");
		Iterator<String> iter = ids.iterator();
		while (iter.hasNext()) {
			buf.append(iter.next()).append(",");
		}
		buf.delete(buf.length() - 1, buf.length()).append(")");
		this.pstmt = this.conn.prepareStatement(buf.toString());
		return this.pstmt.executeUpdate() == ids.size();
	}

	/**
	 * 查询数据表中的全部数据，每行数据通过Book类包装，而后通过List保存多个返回结果
	 * 
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Book> findAll() throws Exception {
		List<Book> list = new ArrayList<Book>();
		String sql = "select * from tb_book";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			Book book = new Book();
			book.setISBN(rs.getString(1));
			book.setTypeId(rs.getInt(2));
			book.setBookName(rs.getString(3));
			book.setAuthor(rs.getString(4));
			book.setPublish(rs.getString(5));
			book.setPublishDate(rs.getDate(6));
			book.setUnitPrice(rs.getDouble(7));
			book.setAmount(rs.getInt(8));
			list.add(book);
		}
		return list;
	}

	/**
	 * 根据书籍的名称bookname取得书籍的信息
	 * 
	 * @param bookname 书籍的名称
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Book> findByName(String bookname) throws Exception {
		List<Book> list = new ArrayList<Book>();
		String sql = "select * from tb_book where bookName like '%" + bookname + "%'";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			Book book = new Book();
			book.setISBN(rs.getString(1));
			book.setTypeId(rs.getInt(2));
			book.setBookName(rs.getString(3));
			book.setAuthor(rs.getString(4));
			book.setPublish(rs.getString(5));
			book.setPublishDate(rs.getDate(6));
			book.setUnitPrice(rs.getDouble(7));
			book.setAmount(rs.getInt(8));
			list.add(book);
		}
		return list;
	}
	/**
	 * 取得数据表的最后一个数据
	 * 
	 * @return 数据表的最后一个数据，如果不存在则返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public Book findLast() throws Exception {
		Book book = null;
		String sql = "SELECT * FROM tb_book WHERE ISBN = (select max(ISBN) from tb_book)";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			book = new Book();
			book.setISBN(rs.getString(1));
			book.setTypeId(rs.getInt(2));
			book.setBookName(rs.getString(3));
			book.setAuthor(rs.getString(4));
			book.setPublish(rs.getString(5));
			book.setPublishDate(rs.getDate(6));
			book.setUnitPrice(rs.getDouble(7));
			book.setAmount(rs.getInt(8));
		}
		return book;
	}

	/**
	 * 分页进行数据表的模糊查询操作，每行数据通过Book类包装，而后通过List保存多个返回结果
	 * 
	 * @param columun      要模糊查询的数据列
	 * @param keyWord     要进行查询的关键字
	 * @param currentPage 当前所在页
	 * @param lineSize    每页显示的数据行数
	 * @return      全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Book> findAllSplit(String columun, String keyWord, Integer currentPage, Integer lineSize)
			throws Exception {
		List<Book> list = new ArrayList<Book>();
		String sql = "select * from"
				+ " (select ISBN,typeId,bookName,author,publish,publishDate,unitPrice,ROWNUM rn FROM tb_book WHERE "
				+ columun + " LIKE ? AND ROWNUM <= ?) temp WHERE temp.rn > ? ";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, "%" + keyWord + "%");
		this.pstmt.setInt(2, currentPage * lineSize);
		this.pstmt.setInt(3, (currentPage - 1) * lineSize);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			Book book = new Book();
			book.setISBN(rs.getString(1));
			book.setTypeId(rs.getInt(2));
			book.setBookName(rs.getString(3));
			book.setAuthor(rs.getString(4));
			book.setPublish(rs.getString(5));
			book.setPublishDate(rs.getDate(6));
			book.setUnitPrice(rs.getDouble(7));
			book.setAmount(rs.getInt(8));
			list.add(book);
		}
		return list;
	}

	/**
	 * 使用COUNT()函数统计数据表中符合查询要求的数据量
	 * 
	 * @param columun  要模糊查询的数据列
	 * @param keyWord 要进行查询的关键字
	 * @return  返回COUNT()的统计结果，如果没有数据满足，则返回内容为0
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public Integer getAllCount(String columun, String keyWord) throws Exception {
		String sql = "SELECT COUNT(*) FROM tb_book WHERE " + columun + " LIKE ? ";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, "%" + keyWord + "%");
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			return rs.getInt(1);
		}
		return null;
	}

	/**
	 * 按字段排序取得所有图书数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<Book> OrderAll(String name, String choose) throws Exception {
		List<Book> list = new ArrayList<Book>();
		String sql = "select * from tb_book";
		if (choose.equals("desc")) {
			sql = "select * from tb_book order by " + name + " desc";
		} else {
			sql = "select * from tb_book order by " + name + " asc";
		}
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			Book book = new Book();
			book.setISBN(rs.getString(1));
			book.setTypeId(rs.getInt(2));
			book.setBookName(rs.getString(3));
			book.setAuthor(rs.getString(4));
			book.setPublish(rs.getString(5));
			book.setPublishDate(rs.getDate(6));
			book.setUnitPrice(rs.getDouble(7));
			book.setAmount(rs.getInt(8));
			list.add(book);
		}
		return list;
	}

	/**
	 * 清空图书表内的所有数据，即删除所有数据
	 * 
	 * @return 如果删除成功则返回true，失败返回false
	 */
	@Override
	public Boolean doRemoveAll() {
		String sql = "delete from tb_book";
		try {
			this.pstmt = this.conn.prepareStatement(sql);
			return this.pstmt.executeUpdate() > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}

}
