package cn.gl.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import cn.gl.dao.IBookTypeDAO;
import cn.gl.vo.Book;
import cn.gl.vo.BookType;

/**
 * 此类为IBookTypeDao的实现类
 * 
 * @author 高丽
 * @version V1.0
 *
 */
public class BookTypeDAOImpl implements IBookTypeDAO {
	/*
	 * 要想操作数据层子类，那么一定要在构造方法中传入Connection接口对象
	 */
	private Connection conn;//数据库连接对象
	
	private PreparedStatement pstmt;//数据库操作对象
	/*
	 * 实例化数据层子类对象，同时传入一个数据库连接对象 conn Connection连接对象，如果为null表示数据库没有打开
	 */
	public BookTypeDAOImpl(Connection conn) {
		this.conn = conn;
	}

	/**
	 * 根据书籍的类型编号id取得书籍类型的信息
	 * 
	 * @param id 书籍的类型编号id
	 * @return 如果查询到则将内容以BookType对象的形式返回，如果查到没有数据返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public BookType findById(Integer id) throws Exception {
		BookType booktype = null;
		String sql = "SELECT * FROM tb_booktype WHERE typeId = ?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setInt(1, id);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			booktype = new BookType();
			booktype.setTypeId(rs.getInt(1));
			booktype.setTypeName(rs.getString(2));
		}
		return booktype;
	}

	/**
	 * 图书类别数据增加的操作，执行的是INSERT语句
	 * 
	 * @param booktype 包含了要增加的数据信息
	 * @return 如果数据增加成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doCreate(BookType booktype) throws Exception {
		String sql = "INSERT INTO tb_booktype(typeName) VALUES(?)";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, booktype.getTypeName());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 更新图书类别书籍信息
	 * 
	 * @param booktype 欲更新的图书类别书籍信息
	 * @return 如果数据修改成功 返回true 否则返回false
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doUpdate(BookType booktype) throws Exception {
		String sql = "UPDATE tb_booktype SET typeName=? WHERE typeId=?";
		this.pstmt = this.conn.prepareStatement(sql);
		this.pstmt.setString(1, booktype.getTypeName());
		this.pstmt.setInt(2, booktype.getTypeId());
		return this.pstmt.executeUpdate() > 0;
	}

	/**
	 * 图书类别数据删除操作，需在执行前根据删除的编号，拼凑出SQL语句
	 * 
	 * @param ids 所有要删除的图书类别编号数据
	 * @return 如果数据删除成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public boolean doRemove(Set<Integer> ids) throws Exception {
		StringBuffer buf = new StringBuffer();
		buf.append("DELETE FROM tb_booktype WHERE typeId IN(");
		Iterator<Integer> iter = ids.iterator();
		while (iter.hasNext()) {
			buf.append(iter.next()).append(",");
		}
		buf.delete(buf.length() - 1, buf.length()).append(")");
		this.pstmt = this.conn.prepareStatement(buf.toString());
		return this.pstmt.executeUpdate() == ids.size();
	}

	/**
	 * 查询数据表中的全部数据，每行数据通过BookType类包装，而后通过List保存多个返回结果
	 * 
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<BookType> findAll() throws Exception {
		List<BookType> list = new ArrayList<>();
		BookType booktype = null;
		String sql = "SELECT * FROM tb_booktype";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			booktype = new BookType();
			booktype.setTypeId(rs.getInt(1));
			booktype.setTypeName(rs.getString(2));
			list.add(booktype);
		}
		return list;
	}

	/**
	 * 取得数据表的最后一个数据
	 * 
	 * @return 数据表的最后一个数据
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public BookType findLast() throws Exception {
		BookType booktype = null;
		String sql = "SELECT * FROM tb_booktype WHERE typeId = (select max(typeId) from tb_booktype)";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		if (rs.next()) {
			booktype = new BookType();
			booktype.setTypeId(rs.getInt(1));
			booktype.setTypeName(rs.getString(2));
		}
		return booktype;
	}

	/**
	 * 根据图书类别的名称取得图书类别信息
	 * 
	 * @param typename 图书类别名称
	 * @return 查询到的所有图书类别信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<BookType> findByName(String typename) throws Exception {
		List<BookType> list = new ArrayList<>();
		BookType booktype = null;
		String sql = "select * from tb_booktype where typeName like '%" + typename + "%'";
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			booktype = new BookType();
			booktype.setTypeId(rs.getInt(1));
			booktype.setTypeName(rs.getString(2));
			list.add(booktype);
		}
		return list;
	}

	/**
	 * 按字段排序取得所有图书类别数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	@Override
	public List<BookType> OrderAll(String name, String choose) throws Exception {
		List<BookType> list = new ArrayList<BookType>();
		BookType booktype = null;
		String sql = "select * from tb_booktype";
		if (choose.equals("desc")) {
			sql = "select * from tb_booktype order by " + name + " desc";
		} else {
			sql = "select * from tb_booktype order by " + name + " asc";
		}
		this.pstmt = this.conn.prepareStatement(sql);
		ResultSet rs = this.pstmt.executeQuery();
		while (rs.next()) {
			booktype = new BookType();
			booktype.setTypeId(rs.getInt(1));
			booktype.setTypeName(rs.getString(2));
			list.add(booktype);
		}
		return list;
	}
}
