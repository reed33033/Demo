package cn.gl.dao;

import java.util.List;
/**
 *  此类为读者信息表的数据层操作标准
 */
import java.util.Set;

import cn.gl.vo.Reader;

/**
 * 此类为读者信息表的数据层操作标准
 * 
 * @author 高丽
 * @version V1.0
 */
public interface IReaderDAO extends IDAO<Integer, Reader> {
	/**
	 * 取得数据表的最后一个数据
	 * 
	 * @return 数据表的最后一个数据，如果不存在则返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public Reader findLast() throws Exception;

	/**
	 * 根据读者的姓名取得读者信息
	 * 
	 * @param name 读者姓名
	 * @return 查询到的读者的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<Reader> findByName(String name) throws Exception;
}
