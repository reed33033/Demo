package cn.gl.dao;

import java.util.List;
import java.util.Set;

import cn.gl.vo.Book;
import cn.gl.vo.Borrow;
import cn.gl.vo.User;

/**
 * 此类为借还表的数据层操作标准
 * 
 * @author 高丽
 * @version V1.0
 */
public interface IBorrowDAO extends IDAO<Integer, Borrow> {
	/**
	 * 根据读者借书的编号id取得借书记录信息
	 * 
	 * @param id 读者编号借书编号
	 * @return 查询到的读者所有借书记录的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<Borrow> findByReaderId(Integer id) throws Exception;

	/**
	 * 根据读者借书的编号和书籍编号取得借书记录信息
	 * 
	 * @param readerId 读者编号
	 * @param ISBN   书籍编号
	 * @return 如果查询到则将内容以Borrow对象的形式返回，如果查到没有数据返回null
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public Borrow findByISBN(Integer readerId, String ISBN) throws Exception;
}
