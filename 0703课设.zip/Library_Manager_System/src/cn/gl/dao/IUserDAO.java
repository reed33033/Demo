package cn.gl.dao;

import java.util.List;
import java.util.Set;

import cn.gl.vo.User;
/**
 *  此类为用户表的数据层操作标准
 *  @author 高丽
 *  @version V1.0
 */
public interface IUserDAO{
	 /**
     * 添加用户
     * @param user 欲添加的用户
     * @return 如果数据增加成功 返回true 否则返回false
     * @exception Exception 文件操作失败则会产生IOException
     */
    public boolean doCreate(User user) throws Exception;
    /**
     * 更新用户信息
     * @param user 欲更新的用户信息
     * @return 如果数据修改成功 返回true 否则返回false
     * @exception Exception 文件操作失败则会产生IOException
     */
    public boolean doUpdate(User user) throws Exception;
    /**
     * 删除用户
     * @param id 所有要删除的用户编号
     * @return 如果数据删除成功 返回true 否则返回false
     * @exception Exception 文件操作失败则会产生IOException
     */
    public boolean doRemove(String ids) throws Exception;
    /**
     * 根据用户名取得用户信息
     * @param userName 用户名
     * @return 如果查询到则将内容以User对象的形式返回，如果查到没有数据返回null
     * @author Administrator Exception 文件操作失败则会产生IOException
     */
    public User findById(String userName) throws Exception;
    /**
     * 根据用户名和密码取得用户信息
     * @param userName 用户的姓名
     * @param password 用户密码
     * @return 如果查询到则将内容以User对象的形式返回，如果查到没有数据返回null
     * @exception Exception 文件操作失败则会产生IOException
     */
    public User findByName(String userName,String password) throws Exception;
	
	 /**
     * 取得所有用户信息
     * @return 所有用户信息的集合,如果没有数据返回，集合长度为0（size() = 0）
     * @exception Exception 文件操作失败则会产生IOException
     */
    public List<User> findAll() throws Exception;
    
	/**
	 * 按字段排序取得所有用户信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有用户信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 */
	public List<User> OrderAll(String name, String choose) throws Exception;
   
}
