package cn.gl.dao;

import java.util.List;
import java.util.Set;

import cn.gl.vo.User;

/**
 * 本类为数据表的数据层操作标准
 * 
 * @author 高丽
 * @version V1.0
 * @param <K>要操作数据表的主键数据类型
 * @param <V>要操作的数据类型
 */
public interface IDAO<K, V> {
	/**
	 * 数据增加的操作，执行的是INSERT语句
	 * 
	 * @param vo 包含了要增加的数据信息
	 * @return 如果数据增加成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public boolean doCreate(V vo) throws Exception;

	/**
	 * 数据修改操作，执行UPDATE语句，本次的修改会根据Id将所有的数据进行变更
	 * 
	 * @param vo 包含了要修改数据的信息
	 * @return 如果数据修改成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 * 
	 */
	public boolean doUpdate(V vo) throws Exception;

	/**
	 * 数据删除操作，需在执行前根据删除的编号，拼凑出SQL语句
	 * 
	 * @param ids 所有要删除的编号数据
	 * @return 如果数据删除成功 返回true 否则返回false
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public boolean doRemove(Set<K> ids) throws Exception;

	/**
	 * 根据编号查询出表一行的完整信息，并且将返回结果填充到V类对象中 
	 * 
	 * @param id 要查询的数据编号
	 * @return 如果查询到则将内容以V对象的形式返回，如果查到没有数据返回null
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public V findById(K id) throws Exception;

	/**
	 * 查询数据表中的全部数据，每行数据通过V类包装，而后通过List保存多个返回结果 
	 * 
	 * @return 全部的查询数据行，如果没有数据返回，集合长度为0（size() = 0）。
	 * @throws Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<V> findAll() throws Exception;

	/**
	 * 按字段排序取得所有数据信息
	 * 
	 * @param name   要进行排序的字段名
	 * @param choose 排序的方式，desc为降序，asc为升序
	 * @return 所有数据信息的集合,如果没有数据返回，集合长度为0（size() = 0）
	 * @exception Exception 如果数据库没有连接，则出现NullPointerException,如果SQL语句错误抛出SQLException
	 */
	public List<V> OrderAll(String name, String choose) throws Exception;
}
