package cn.gl.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 本类对读者进行封装
 * 
 * @author 高丽
 * @version V1.0
 */
@SuppressWarnings("serial")
public class Reader implements Serializable {
	private Integer readerId;
	private String readerName;
	private String readerSex;
	private Integer readerAge;
	private String readerIdCard;
	private Date regdate;
	private String readerPhone;
	private Integer maxNum;
	private Double keepMoney;

	public Integer getReaderId() {
		return readerId;
	}

	public void setReaderId(Integer readerId) {
		this.readerId = readerId;
	}

	public String getReaderName() {
		return readerName;
	}

	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}

	public String getReaderSex() {
		return readerSex;
	}

	public void setReaderSex(String readerSex) {
		this.readerSex = readerSex;
	}

	public Integer getReaderAge() {
		return readerAge;
	}

	public void setReaderAge(Integer readerAge) {
		this.readerAge = readerAge;
	}

	public String getReaderIdCard() {
		return readerIdCard;
	}

	public void setReaderIdCard(String readerIdCard) {
		this.readerIdCard = readerIdCard;
	}

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String getReaderPhone() {
		return readerPhone;
	}

	public void setReaderPhone(String readerPhone) {
		this.readerPhone = readerPhone;
	}

	public Integer getMaxNum() {
		return maxNum;
	}

	public void setMaxNum(Integer maxNum) {
		this.maxNum = maxNum;
	}

	public Double getKeepMoney() {
		return keepMoney;
	}

	public void setKeepMoney(Double keepMoney) {
		this.keepMoney = keepMoney;
	}

}
