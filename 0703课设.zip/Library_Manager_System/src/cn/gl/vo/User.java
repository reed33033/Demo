package cn.gl.vo;

import java.io.Serializable;
import java.sql.Date;

/**
 * 本类对用户进行封装
 * 
 * @author 高丽
 * @version V1.0
 */
@SuppressWarnings("serial")
public class User implements Serializable {
	private String userName;
	private String password;

	public User() {
	}

	public User(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
