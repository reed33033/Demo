package cn.gl.vo;

import java.io.Serializable;
import java.util.Date;
/**
 * 本类对借还书进行封装
 * 
 * @author 高丽
 * @version V1.0
 */
@SuppressWarnings("serial")
public class Borrow implements Serializable{
	private Integer borrowId;
	private String ISBN;
	private String userName;
	private Integer readerId;
	private Date borrowDate;
	private Date returnDate;
	private double fine;
	public Borrow() {}	
	
	
	public Borrow(String iSBN, String userName, Integer readerId, Date borrowDate, Date returnDate,
			double fine) {
		ISBN = iSBN;
		this.userName = userName;
		this.readerId = readerId;
		this.borrowDate = borrowDate;
		this.returnDate = returnDate;
		this.fine = fine;
	}



	public Integer getBorrowId() {
		return borrowId;
	}
	public void setBorrowId(Integer borrowId) {
		this.borrowId = borrowId;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getReaderId() {
		return readerId;
	}
	public void setReaderId(Integer readerId) {
		this.readerId = readerId;
	}
	public Date getBorrowDate() {
		return borrowDate;
	}
	public void setBorrowDate(Date borrowDate) {
		this.borrowDate = borrowDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public double getFine() {
		return fine;
	}
	public void setFine(double fine) {
		this.fine = fine;
	}
	
	
	
}
