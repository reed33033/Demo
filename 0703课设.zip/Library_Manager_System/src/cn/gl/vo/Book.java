package cn.gl.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 本类对图书进行封装
 * 
 * @author 高丽
 * @version V1.0
 */
@SuppressWarnings("serial")
public class Book implements Serializable {
	private String ISBN;
	private Integer typeId;
	private String bookName;
	private String author;
	private String publish;
	private Date publishDate;
	private Double unitPrice;
	private Integer amount;

	public Book() {
	}

	public Book(String iSBN, Integer typeId, String bookName, String author, String publish, Date publishDate,
			Double unitPrice, Integer amount) {
		super();
		ISBN = iSBN;
		this.typeId = typeId;
		this.bookName = bookName;
		this.author = author;
		this.publish = publish;
		this.publishDate = publishDate;
		this.unitPrice = unitPrice;
		this.amount = amount;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPublish() {
		return publish;
	}

	public void setPublish(String publish) {
		this.publish = publish;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public Double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(Double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

}
